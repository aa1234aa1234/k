#include "header.h"
#include "UIComponent.h"

#pragma once
template<class T>
class Panel : public UIComponent
{
	static_assert(std::is_base_of<UIComponent, T>::value, "type must be UIComponent");
	T* viewComponent;
public:
	Panel() : UIComponent() {}
	Panel(const glm::vec2& pos, const glm::vec2& size, T* component) : UIComponent(pos, size) {
		viewComponent = component;
		uielement = { position, glm::vec3(0,0,0), size, 2 };
	}
	~Panel() {
		destroy();
		delete viewComponent;
	}

	Element DrawComponent() override {
		viewComponent->renderScene();
		glBindTexture(GL_TEXTURE_2D, viewComponent->getSceneTexture());
		return uielement;
	}

	int onClick(glm::vec2 pos) override {
		viewComponent->onClick(pos);
		return viewComponent->getComponentId();
	}
};

