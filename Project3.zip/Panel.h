#include "header.h"
#include "UIComponent.h"

#pragma once
class Panel : public UIComponent
{
	UIComponent* viewComponent;
public:
	Panel() : UIComponent() {}
	Panel(const glm::vec2& pos, const glm::vec2& size) : UIComponent(pos, size) {}
	~Panel() {
		destroy();
		delete viewComponent;
	}
};

