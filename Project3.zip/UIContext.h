#pragma once
#include "header.h"
#include "UIComponent.h"
#include <map>
#define MAX_COMPONENTS 10000

enum Layout {
	LEFT,
	RIGHT,
	CENTER,
	TOP,
	BOTTOM
};

class UIContext
{
	std::vector<UIComponent*> rootComponents;
	std::vector<Element*> instanceData;
	std::vector<Element> dataBuffer;
	Shader* shader;
	unsigned int vao,vbo,instancevbo;
	int width, height;
public:
	UIContext();
	~UIContext() {
		glDeleteVertexArrays(1, &vao);
		glDeleteBuffers(1, &vbo);
		glDeleteBuffers(1, &instancevbo);
		delete shader;
		for (auto& p : rootComponents) {
			delete p;
		}
		rootComponents.clear();
		for (auto& p : instanceData) {
			//delete p;
		}
		instanceData.clear();
	}
	void add(UIComponent* component);
	void init();
	void setSize(int& width, int& height);
	void DrawComponents();
	void pack();
};

