#pragma once
#include "header.h"
#include "UIComponent.h"
#include <map>
#define MAX_COMPONENTS 99

enum Layout {
	LEFT,
	RIGHT,
	CENTER,
	TOP,
	BOTTOM
};

class UIContext
{
	std::vector<UIComponent*> rootComponents;
	std::map<int,std::vector<UIComponent*>> componentLayout;
	Shader* shader;
	unsigned int vao,vbo;
	int width, height;
public:
	UIContext();
	~UIContext() {
		glDeleteVertexArrays(1, &vao);
		glDeleteBuffers(1, &vbo);
		delete shader;
		for (auto& p : rootComponents) {
			delete p;
		}
		rootComponents.clear();
	}
	void add(UIComponent* component, int layout);
	void setSize(int& width, int& height);
	void DrawComponents();
	void pack();
};

