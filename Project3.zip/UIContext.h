#pragma once
#include "header.h"
#include "UIComponent.h"
class UIContext
{
	std::vector<UIComponent*> components;
};

