#pragma once
#include "header.h"
#include "UIComponent.h"
#define MAX_COMPONENTS 99
class UIContext
{
	std::vector<UIComponent*> components;
	Shader* shader;
	unsigned int vao,vbo;
public:
	UIContext();
	~UIContext() {
		delete shader;
		for (auto& p : components) {
			delete p;
		}
		components.clear();
	}
	void add(UIComponent* component);
	void DrawComponents(int& width, int& height);
};

