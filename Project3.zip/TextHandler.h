#pragma once
#include "header.h"
#include <stb/stb_image.h>
#include "FrameBuffer.h"
#include "Shader.h"
#include <map>

typedef struct Character {
	int x, y, width, height, originX, originY, advance;
};

class TextHandler {
	FrameBuffer* textBuffer;
	int width, height, textureWidth, textureHeight;
	unsigned int textureId;
	std::map<char, Character> characters;
    Shader* shader;
    unsigned int vao, vbo;
public:
	TextHandler(int w, int h, const char* filepath) : width(std::move(w)), height(std::move(h)) {
		textBuffer = new FrameBuffer();
        shader = new Shader("shader/vertex3.glsl", "shader/frag3.glsl");
		textBuffer->init(width, height);
		ImportAtlas(filepath);
        glGenBuffers(1, &vbo);
        glGenVertexArrays(1, &vao);
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, 6 * 4 * sizeof(float), NULL, GL_DYNAMIC_DRAW);
        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 4, (void*)0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 4, (void*)(sizeof(float)*2));
        glEnableVertexAttribArray(1);
        glBindVertexArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
	}
	~TextHandler() {
		delete textBuffer;
		/*for (auto& p : text) {
			delete p;
		}
		text.clear();*/
        delete shader;
		glDeleteTextures(1, &textureId);
        glDeleteVertexArrays(1, &vao);
        glDeleteBuffers(1, &vbo);
	}
	void draw(float posx, float posy, std::string text) {
        shader->use();
        glm::mat4 projection = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
        //glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "projection"), 1, GL_FALSE, glm::value_ptr(projection));
        for (auto& p : text) {
            glBindTexture(GL_TEXTURE_2D, textureId);
            glBindVertexArray(vao);
            Character ch = characters[p];
            float xpos = (posx - ch.originX * 2.0f) / (float)width, xpos1 = xpos + ch.width * 2.0f / (float)width;
            float ypos = (posy - (ch.height - ch.originY) * 2.0f) / (float)height, ypos1 = ypos + ch.height * 2.0f / (float)height;
            float x = ch.x / (float)textureWidth, y1 = ch.y / (float)textureHeight;
            float x1 = (ch.x + ch.width) / (float)textureWidth, y = (ch.y + ch.height) / (float)textureHeight;
            glBindBuffer(GL_ARRAY_BUFFER, vbo);

            float vertices[6][4] = {
                xpos, ypos, x, y,
                xpos1, ypos, x1, y,
                xpos1, ypos1, x1, y1,
                xpos, ypos, x, y,
                xpos1, ypos1, x1, y1,
                xpos, ypos1, x, y1
            };
            glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(float) * 6 * 4, vertices);
            glDrawArrays(GL_TRIANGLES, 0, 6);
            posx += ch.advance * 2.0;
        }
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
	}
	void ImportAtlas(const char* path) {
		glGenTextures(1, &textureId);
		int components;
		unsigned char* data = stbi_load(path, &textureWidth, &textureHeight, &components, 0);
		if (data) {
			GLenum format;
			switch (components) {
			case 1:
				format = GL_RED;
				break;
			case 3:
				format = GL_RGB;
				break;
			case 4:
				format = GL_RGBA;
				break;
			}
			glBindTexture(GL_TEXTURE_2D, textureId);
			glTexImage2D(GL_TEXTURE_2D, 0, format, textureWidth, textureHeight, 0, format, GL_UNSIGNED_BYTE, data);
			glGenerateMipmap(GL_TEXTURE_2D);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			stbi_image_free(data);
			glBindTexture(GL_TEXTURE_2D, 0);
		}
		else {
			std::cout << "texture failed to load " << path << std::endl;
			stbi_image_free(data);
		}

        characters = {
    {'0', {95, 43, 18, 20, 6, 14, 6}},
    {'1', {103, 63, 16, 20, 5, 14, 6}},
    {'2', {113, 43, 18, 20, 6, 14, 6}},
    {'3', {131, 43, 18, 20, 6, 14, 6}},
    {'4', {149, 43, 18, 20, 6, 14, 6}},
    {'5', {167, 43, 18, 20, 6, 14, 6}},
    {'6', {185, 43, 18, 20, 6, 14, 6}},
    {'7', {203, 43, 18, 20, 6, 14, 6}},
    {'8', {221, 43, 18, 20, 6, 14, 6}},
    {'9', {239, 43, 18, 20, 6, 14, 6}},
    {' ', {82, 101, 12, 12, 6, 6, 3}},
    {'!', {166, 63, 14, 20, 5, 14, 3}},
    {'"', {261, 83, 16, 15, 6, 14, 4}},
    {'#', {202, 23, 19, 20, 6, 14, 6}},
    {'$', {144, 0, 18, 22, 6, 15, 6}},
    {'%', {278, 0, 22, 20, 5, 14, 10}},
    {'&', {42, 23, 20, 20, 6, 14, 8}},
    {'\'', {293, 83, 14, 15, 6, 14, 2}},
    {'(', {55, 0, 15, 23, 5, 14, 4}},
    {')', {70, 0, 15, 23, 5, 14, 4}},
    {'*', {277, 83, 16, 15, 6, 14, 4}},
    {'+', {276, 63, 18, 18, 5, 13, 7}},
    {',', {307, 83, 14, 14, 5, 7, 3}},
    {'-', {38, 101, 16, 13, 6, 9, 4}},
    {'.', {54, 101, 14, 13, 5, 7, 3}},
    {'/', {87, 63, 16, 20, 6, 14, 3}},
    {':', {212, 83, 14, 18, 5, 12, 3}},
    {';', {220, 63, 14, 19, 5, 12, 3}},
    {'<', {294, 63, 18, 18, 5, 13, 7}},
    {'=', {243, 83, 18, 15, 5, 12, 7}},
    {'>', {0, 83, 18, 18, 5, 13, 7}},
    {'?', {257, 43, 18, 20, 6, 14, 6}},
    {'@', {0, 0, 23, 23, 5, 14, 12}},
    {'A', {300, 0, 21, 20, 6, 14, 8}},
    {'B', {221, 23, 19, 20, 5, 14, 8}},
    {'C', {62, 23, 20, 20, 6, 14, 8}},
    {'D', {82, 23, 20, 20, 5, 14, 8}},
    {'E', {240, 23, 19, 20, 5, 14, 8}},
    {'F', {275, 43, 18, 20, 5, 14, 7}},
    {'G', {102, 23, 20, 20, 5, 14, 9}},
    {'H', {259, 23, 19, 20, 5, 14, 8}},
    {'I', {180, 63, 14, 20, 5, 14, 3}},
    {'J', {36, 63, 17, 20, 6, 14, 6}},
    {'K', {278, 23, 19, 20, 5, 14, 8}},
    {'L', {293, 43, 18, 20, 5, 14, 6}},
    {'M', {0, 23, 21, 20, 5, 14, 10}},
    {'N', {297, 23, 19, 20, 5, 14, 8}},
    {'O', {21, 23, 21, 20, 6, 14, 9}},
    {'P', {0, 43, 19, 20, 5, 14, 8}},
    {'Q', {162, 0, 21, 21, 6, 14, 9}},
    {'R', {122, 23, 20, 20, 5, 14, 8}},
    {'S', {19, 43, 19, 20, 6, 14, 8}},
    {'T', {38, 43, 19, 20, 6, 14, 7}},
    {'U', {57, 43, 19, 20, 5, 14, 8}},
    {'V', {142, 23, 20, 20, 6, 14, 8}},
    {'W', {255, 0, 23, 20, 6, 14, 11}},
    {'X', {162, 23, 20, 20, 6, 14, 8}},
    {'Y', {182, 23, 20, 20, 6, 14, 8}},
    {'Z', {76, 43, 19, 20, 6, 14, 7}},
    {'[', {85, 0, 15, 23, 5, 14, 3}},
    {'\\', {119, 63, 16, 20, 6, 14, 3}},
    {']', {100, 0, 15, 23, 6, 14, 3}},
    {'^', {226, 83, 17, 16, 6, 14, 5}},
    {'_', {0, 101, 19, 13, 6, 4, 6}},
    {'`', {68, 101, 14, 13, 5, 14, 4}},
    {'a', {18, 83, 18, 18, 6, 12, 6}},
    {'b', {0, 63, 18, 20, 5, 14, 6}},
    {'c', {36, 83, 18, 18, 6, 12, 6}},
    {'d', {18, 63, 18, 20, 6, 14, 6}},
    {'e', {54, 83, 18, 18, 6, 12, 6}},
    {'f', {135, 63, 16, 20, 6, 14, 3}},
    {'g', {183, 0, 18, 21, 6, 12, 6}},
    {'h', {53, 63, 17, 20, 5, 14, 6}},
    {'i', {194, 63, 13, 20, 5, 14, 2}},
    {'j', {115, 0, 15, 23, 7, 14, 2}},
    {'k', {70, 63, 17, 20, 5, 14, 6}},
    {'l', {207, 63, 13, 20, 5, 14, 2}},
    {'m', {234, 63, 21, 18, 5, 12, 10}},
    {'n', {162, 83, 17, 18, 5, 12, 6}},
    {'o', {72, 83, 18, 18, 6, 12, 6}},
    {'p', {201, 0, 18, 21, 5, 12, 6}},
    {'q', {219, 0, 18, 21, 6, 12, 6}},
    {'r', {196, 83, 16, 18, 5, 12, 4}},
    {'s', {90, 83, 18, 18, 6, 12, 6}},
    {'t', {151, 63, 15, 20, 6, 14, 3}},
    {'u', {179, 83, 17, 18, 5, 12, 6}},
    {'v', {108, 83, 18, 18, 6, 12, 6}},
    {'w', {255, 63, 21, 18, 6, 12, 8}},
    {'x', {126, 83, 18, 18, 6, 12, 6}},
    {'y', {237, 0, 18, 21, 6, 12, 6}},
    {'z', {144, 83, 18, 18, 6, 12, 6}},
    {'{', {23, 0, 16, 23, 6, 14, 4}},
    {'|', {130, 0, 14, 23, 5, 14, 3}},
    {'}', {39, 0, 16, 23, 6, 14, 4}},
    {'~', {19, 101, 19, 13, 6, 11, 7}}
        };
	}
};


class Text {
public:
	Text() {
	}
	~Text() {

	}
};
