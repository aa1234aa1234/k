#pragma once
#include "header.h"
#include <stb/stb_image.h>
#include "FrameBuffer.h"
#include "Shader.h"
#include <map>

class TextHandler {
	FrameBuffer* textBuffer;
	std::vector<Text*> text;
	int width, height;
	unsigned int textureId;
	std::map<char, glm::vec2> characters;
public:
	TextHandler(int w, int h, const char* filepath) : width(std::move(w)), height(std::move(h)) {
		textBuffer = new FrameBuffer();
		textBuffer->init(width, height);
		ImportAtlas(filepath);
	}
	~TextHandler() {
		delete textBuffer;
		for (auto& p : text) {
			delete p;
		}
		text.clear();
		glDeleteTextures(1, &textureId);
	}
	void draw(Shader* shader) {
		
	}
	void ImportAtlas(const char* path) {
		glGenTextures(1, &textureId);
		int w, h, components;
		unsigned char* data = stbi_load(path, &w, &h, &components, 0);
		if (data) {
			GLenum format;
			switch (components) {
			case 1:
				format = GL_RED;
				break;
			case 3:
				format = GL_RGB;
				break;
			case 4:
				format = GL_RGBA;
				break;
			}
			glBindTexture(GL_TEXTURE_2D, textureId);
			glTexImage2D(GL_TEXTURE_2D, 0, format, w, h, 0, format, GL_UNSIGNED_BYTE, data);
			glGenerateMipmap(GL_TEXTURE_2D);

			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			stbi_image_free(data);
			glBindTexture(GL_TEXTURE_2D, 0);
		}
		else {
			std::cout << "texture failed to load " << path << std::endl;
			stbi_image_free(data);
		}
	}
};


class Text {
public:
	Text() {
	}
	~Text() {

	}
};
