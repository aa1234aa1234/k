#pragma once
#include "header.h"

class Text {

};