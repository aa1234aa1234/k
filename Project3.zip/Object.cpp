#include "Object.h"

Object::Object(Model model) {
	this->model = std::move(model);
}

Object::~Object() {

}

glm::mat4 Object::getModelMatrix() {
	modelMatrix = glm::translate(glm::mat4(1.0f), model.position);
	modelMatrix = glm::scale(modelMatrix, model.scale);
	return modelMatrix;
}

void Object::Draw(Shader& shader) {
	model.Draw(shader);
}
