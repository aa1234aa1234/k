#pragma once
#include "header.h"
#include "Shader.h"
#include <queue>

struct UIElements {
	glm::vec2 position;
	glm::vec2 texcoord;
	glm::vec3 colors;
};

typedef struct Element {
	glm::vec2 position;;
	glm::vec3 color;
	glm::vec2 size;
	int id;
};


class UIComponent
{
protected:
	void destroy();
public:
	UIComponent* parentComponent;
	std::vector<UIComponent*> childComponents;
	Element uielement;
	glm::vec2 position;
	glm::vec3 size;
	UIComponent(const glm::vec2& pos, const glm::vec2& size);
	UIComponent();
	~UIComponent();
	
	virtual void genVertices();
	virtual Element DrawComponent();
	virtual void Update();
	virtual void getUIElements(std::vector<Element>& v);
	void generateQuad(glm::vec3 color);
	void addChildComponent(UIComponent* child);
};

