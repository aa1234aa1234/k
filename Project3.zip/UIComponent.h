#pragma once
#include "header.h"
#include "Shader.h"

struct UIElements {
	glm::vec2 position;
	glm::vec2 texcoord;
	glm::vec3 colors;
};


class UIComponent
{
public:
	UIComponent* parentComponent;
	std::vector<UIComponent*> childComponents;
	std::vector<UIElements> uielements;
	glm::vec2 position,borderpos;
	glm::vec3 size;
	UIComponent(const glm::vec2& pos, const glm::vec2& size);
	UIComponent();
	~UIComponent();
	virtual void genVertices();
	virtual void DrawComponent(Shader* shader);
	virtual void Update(Shader* shader);
	void generateQuad();
};

