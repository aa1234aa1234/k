#pragma once
#include "header.h"
#include "Shader.h"

struct UIElements {
	glm::vec2 position;
	glm::vec2 texcoord;
	glm::vec3 colors;
};

struct Element {
	glm::vec2 position;;
	glm::vec3 color;
	glm::vec2 size;
	int id;
};


class UIComponent
{
protected:
	void destroy();
public:
	UIComponent* parentComponent;
	std::vector<UIComponent*> childComponents;
	glm::vec2 position;
	glm::vec3 size;
	UIComponent(const glm::vec2& pos, const glm::vec2& size);
	UIComponent();
	~UIComponent();
	
	virtual void genVertices();
	virtual std::vector<Element*> DrawComponent();
	virtual void Update();
	void generateQuad(glm::vec3 color);
};

