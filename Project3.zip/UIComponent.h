#pragma once
#include "header.h"
#include "Shader.h"
class UIComponent
{
	glm::vec2 position;
	glm::vec2 size;
	glm::vec4 color;
public:
	virtual void Draw(Shader& shader);
	UIComponent();
	~UIComponent();
};

