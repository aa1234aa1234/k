#pragma once
#include "header.h"
#include "Shader.h"

struct UIElements {
	glm::vec2 position;
	glm::vec2 texcoord;
	glm::vec3 colors;
};

class UIComponent
{
public:
	std::vector<UIElements> uielements;
	glm::vec2 position;
	glm::vec3 size;
	glm::vec4 color;
	UIComponent(const glm::vec2& pos);
	~UIComponent();
	virtual void genVertices();
};

