#include "UIContext.h"

UIContext::UIContext() {
	shader = new Shader("shader/vertex2.glsl", "shader/frag2.glsl");
	glGenVertexArrays(1, &vao);
	glGenBuffers(1, &vbo);
	glBindVertexArray(vao);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, MAX_COMPONENTS * sizeof(UIElements), NULL, GL_DYNAMIC_DRAW);
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)(offsetof(UIElements,texcoord)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)(offsetof(UIElements, colors)));
	glEnableVertexAttribArray(2);
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void UIContext::add(UIComponent* component, int layout) {
	components.reserve(components.size() + 1);
	components.emplace_back(component);
	int x = 0, size = 0;
	if (componentLayout[layout].size() != 0) {
		x = componentLayout[layout].back()->position.x + componentLayout[layout].back()->size.x;
		for (auto& p : componentLayout[layout]) size += p->size.x;
	}
	switch (layout) {
	case LEFT:
		component->position = glm::vec2(0.0 + x, 0.0);
		component->size.y = height;
		break;
	case RIGHT:
		component->position = glm::vec2(width - component->size.x - size, 0.0);
		component->size.y = height;
		break;
	}
	componentLayout[layout].reserve(componentLayout[layout].size() + 1);
	componentLayout[layout].emplace_back(component);
	
}

void UIContext::setSize(int& width, int& height) {
	this->width = width;
	this->height = height;
	for (auto& p : componentLayout) {
		int x = 0;
		if (p.second.size() != 0) {
			for (auto& k : p.second) {
				switch (p.first) {
				case LEFT:
					k->position = glm::vec2(0.0 + x, 0.0);
					k->size.y = height;
					break;
				case RIGHT:
					k->position = glm::vec2(width - k->size.x - x, 0.0);
					k->size.y = height;
					break;
				}
				x += p.second.back()->position.x;
			}
			
		}
		
	}
	pack();
}

void UIContext::DrawComponents() {
	shader->use();
	float aspect = (float)width / height;
	glm::mat4 mat = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
	//glm::mat4 mat = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
	glUniform1f(glGetUniformLocation(shader->getId(), "width"), (float)width);
	glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "projection"), 1, GL_FALSE, glm::value_ptr(mat));
	glBindVertexArray(vao);
	for (auto& p : components) {
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(UIElements) * p->uielements.size(), p->uielements.data());
		
		
		p->DrawComponent(shader);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}
	glBindVertexArray(0);
}

void UIContext::pack() {
	if (componentLayout[CENTER].size() == 0) return;
	int left = componentLayout[LEFT].size() != 0 ? componentLayout[LEFT].back()->position.x+componentLayout[LEFT].back()->size.x : 0;
	int right = componentLayout[RIGHT].size() != 0 ? componentLayout[RIGHT].back()->position.x : width;
	int bottom = componentLayout[BOTTOM].size() != 0 ? componentLayout[BOTTOM].back()->position.y : 0;
	int top = componentLayout[TOP].size() != 0 ? componentLayout[TOP].back()->position.y + componentLayout[TOP].back()->size.y : 0;
	componentLayout[CENTER].back()->position = glm::vec2(left, top);
	componentLayout[CENTER].back()->size = glm::vec3(right - left, height - bottom, 0.0);
}
