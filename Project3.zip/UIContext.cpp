#include "UIContext.h"

UIContext::UIContext() {
	shader = new Shader("shader/vertex2.glsl", "shader/frag2.glsl");
	float ndc[] = { 
		1.0, 1.0 ,
		1.0,-1.0, 
		-1.0,1.0, 
		-1.0,-1.0, 
		1.0,-1.0, 
		-1.0,1.0,
	};
	glGenVertexArrays(1, &vao);
	glGenBuffers(1, &vbo);
	glGenBuffers(1, &instancevbo);
	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	glBufferData(GL_ARRAY_BUFFER, MAX_COMPONENTS * sizeof(Element), NULL, GL_DYNAMIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(vao);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(ndc), ndc, GL_STATIC_DRAW);
	
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)0);
	glEnableVertexAttribArray(1);
	glVertexAttribDivisor(1, 1);

	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)(offsetof(Element, color)));
	glEnableVertexAttribArray(2);
	glVertexAttribDivisor(2, 1);

	glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)(offsetof(Element, size)));
	glEnableVertexAttribArray(3);
	glVertexAttribDivisor(3, 1);

	glVertexAttribIPointer(4, 1, GL_INT, sizeof(Element), (void*)(offsetof(Element, id)));
	glEnableVertexAttribArray(4);
	glVertexAttribDivisor(4, 1);

	
	
	
	
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void UIContext::add(UIComponent* component) {
	component->getUIElements(dataBuffer);

	rootComponents.reserve(rootComponents.size() + 1);
	rootComponents.emplace_back(component);
	
	
}

void UIContext::setup() {
	int n = 0, m = 0;
	size_t size = 0;
	instanceData.reserve(instanceData.size() + dataBuffer.size());
	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	for (int i = 0; i < dataBuffer.size(); i++) {
		//rootComponents[i]->DrawComponent();
		
		
		
		instanceData.emplace_back(&dataBuffer[i]);
		
		
		
		
		n++;
	}
	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(Element) * dataBuffer.size(), dataBuffer.data());
	std::vector<Element> fw(dataBuffer.size());
	glGetBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(Element) * dataBuffer.size(), fw.data());
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void UIContext::setSize(int& width, int& height) {
	int a = this->width - width, b = this->height - height;
	this->width = width, this->height = height;
	for (auto& p : rootComponents) {
		p->size.x += a;
		p->size.y += b;
		p->Update();
	}
}

void UIContext::DrawComponents() {
	shader->use();
	//float aspect = (float)width / height;
	glm::mat4 mat = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
	glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "projection"), 1, GL_FALSE, glm::value_ptr(mat));
	/*int i = 0;
	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	for (auto& p : rootComponents) {
		
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(UIElements) * p->uielements.size(), p->uielements.data());
		
		
		for (auto& k : p->DrawComponent()) {
			instanceData[i] = k;
			i++;
		}
		i++;
	}*/
	for (auto& p : rootComponents) {
		p->DrawComponent();
	}
	glBindVertexArray(vao);
	
	glDrawArraysInstanced(GL_TRIANGLES, 0, 6, instanceData.size());
	//glDrawArrays(GL_TRIANGLES, 0, 6);

	GLenum err;
	while ((err = glGetError()) != GL_NO_ERROR) {
		std::cout << err << " uicontext" << std::endl;
	} 
	glBindVertexArray(0);
}

void UIContext::pack() {
}
