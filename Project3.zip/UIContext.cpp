#include "UIContext.h"

UIContext::UIContext() {
	shader = new Shader("shader/vertex2.glsl", "shader/frag2.glsl");
	glGenVertexArrays(1, &vao);
	glGenBuffers(1, &vbo);
	glBindVertexArray(vao);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, MAX_COMPONENTS * sizeof(UIElements), NULL, GL_DYNAMIC_DRAW);
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)(offsetof(UIElements,texcoord)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)(offsetof(UIElements, colors)));
	glEnableVertexAttribArray(2);
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void UIContext::add(UIComponent* component) {
	rootComponents.reserve(rootComponents.size() + 1);
	rootComponents.emplace_back(component);
}

void UIContext::setSize(int& width, int& height) {
	int a = this->width - width, b = this->height - height;
	for (auto& p : rootComponents) {
		p->size.x += a;
		p->size.y += b;
		p->Update(shader);
	}
}

void UIContext::DrawComponents() {
	shader->use();
	float aspect = (float)width / height;
	glm::mat4 mat = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
	//glm::mat4 mat = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
	glUniform1f(glGetUniformLocation(shader->getId(), "width"), (float)width);
	glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "projection"), 1, GL_FALSE, glm::value_ptr(mat));
	glBindVertexArray(vao);
	for (auto& p : rootComponents) {
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(UIElements) * p->uielements.size(), p->uielements.data());
		
		
		p->DrawComponent(shader);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}
	glBindVertexArray(0);
}

void UIContext::pack() {
}
