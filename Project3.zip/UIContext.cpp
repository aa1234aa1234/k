#include "UIContext.h"

UIContext::UIContext() {
	shader = new Shader("shader/vertex2.glsl", "shader/frag2.glsl");
	glGenVertexArrays(1, &vao);
	glGenBuffers(1, &vbo);
	glBindVertexArray(vao);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, MAX_COMPONENTS * sizeof(UIElements), NULL, GL_DYNAMIC_DRAW);
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)(offsetof(UIElements,texcoord)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, sizeof(UIElements), (void*)(offsetof(UIElements, colors)));
	glEnableVertexAttribArray(2);
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void UIContext::add(UIComponent* component) {
	components.reserve(components.size() + 1);
	components.emplace_back(component);
}

void UIContext::DrawComponents(int& width, int& height) {
	shader->use();
	float aspect = (float)width / height;
	glBindVertexArray(vao);
	for (auto& p : components) {
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(UIElements) * p->uielements.size(), p->uielements.data());
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glm::mat4 mat = glm::ortho(0.0f,4.0f,0.0f,3.0f,0.1f,100.0f);
		glm::mat4 wah = glm::mat4(1.0);
		wah = glm::translate(wah, glm::vec3(1.0, 0.0, 0.0));
		wah = glm::scale(wah, glm::vec3(1.0, 1.0, 0.0));
		glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "projection"), 1, GL_FALSE, glm::value_ptr(mat));
		glDrawArrays(GL_TRIANGLES, 0, p->uielements.size());
	}
	glBindVertexArray(0);
}
