#include "UIContext.h"
#include <functional>


UIContext::UIContext() {
	shader = new Shader("shader/vertex2.glsl", "shader/frag2.glsl");
	float ndc[] = { 
		1.0, 1.0 ,
		1.0,-1.0, 
		-1.0,1.0, 
		-1.0,-1.0, 
		1.0,-1.0, 
		-1.0,1.0,
	};
	glGenVertexArrays(1, &vao);
	glGenBuffers(1, &vbo);
	glGenBuffers(1, &instancevbo);
	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	glBufferData(GL_ARRAY_BUFFER, MAX_COMPONENTS * sizeof(Element), NULL, GL_DYNAMIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(vao);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(ndc), ndc, GL_STATIC_DRAW);
	
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)0);
	glEnableVertexAttribArray(1);
	glVertexAttribDivisor(1, 1);

	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)(offsetof(Element, color)));
	glEnableVertexAttribArray(2);
	glVertexAttribDivisor(2, 1);

	glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)(offsetof(Element, size)));
	glEnableVertexAttribArray(3);
	glVertexAttribDivisor(3, 1);

	glVertexAttribIPointer(4, 1, GL_INT, sizeof(Element), (void*)(offsetof(Element, id)));
	glEnableVertexAttribArray(4);
	glVertexAttribDivisor(4, 1);

	
	
	
	
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void UIContext::add(UIComponent* component) {
	component->getUIElements(dataBuffer, instanceData);

	rootComponents.reserve(rootComponents.size() + 1);
	rootComponents.emplace_back(component);
	
	
}



void UIContext::setup() {
	int n = 0, m = 0;
	size_t size = 0;
	//instanceData.reserve(instanceData.size() + dataBuffer.size());
	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	for (int i = 0; i < dataBuffer.size(); i++) {
		//rootComponents[i]->DrawComponent();
		
		
		
		//instanceData.emplace_back(&dataBuffer[i]);
		
		
		
		
		n++;
	}
	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(Element) * dataBuffer.size(), dataBuffer.data());
	//std::vector<Element> fw(dataBuffer.size());
	//glGetBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(Element) * dataBuffer.size(), fw.data());
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	//eventHandler->registerEvent(new Event<const glm::vec2&>("drag", std::function<void(const glm::vec2&)>(std::bind(&UIContext::onClick,this,std::placeholders::_1))));
}

void UIContext::setSize(int& width, int& height) {
	int a = this->width - width, b = this->height - height;
	this->width = width, this->height = height;
	shader->use();
	glUniform1f(glGetUniformLocation(shader->getId(), "width"), width);
	glUniform1f(glGetUniformLocation(shader->getId(), "height"), height);
	for (auto& p : rootComponents) {
		p->size.x += a;
		p->size.y += b;
		p->Update();
	}
}

void UIContext::DrawComponents() {
	
	//float aspect = (float)width / height;
	
	/*int i = 0;
	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	for (auto& p : rootComponents) {
		
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(UIElements) * p->uielements.size(), p->uielements.data());
		
		
		for (auto& k : p->DrawComponent()) {
			instanceData[i] = k;
			i++;
		}
		i++;
	}*/
	for (auto& p : rootComponents) {
		p->DrawComponent();
	}
	shader->use();
	glm::mat4 mat = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
	glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "projection"), 1, GL_FALSE, glm::value_ptr(mat));
	glBindVertexArray(vao);
	
	glDrawArraysInstanced(GL_TRIANGLES, 0, 6, instanceData.size());
	//glDrawArrays(GL_TRIANGLES, 0, 6);

	GLenum err;
	while ((err = glGetError()) != GL_NO_ERROR) {
		std::cout << err << " uicontext" << std::endl;
	} 
	glBindVertexArray(0);
}

int UIContext::findComponent(glm::vec2 pos) {
	int id = -1;
	for (auto& p : instanceData) {
		if (pos.x >= p->position.x && pos.x <= p->position.x + p->size.x && pos.y >= p->position.y && pos.y <= p->position.y + p->size.y) {
			id = p->getComponentId();
		}
	}
	return id == targetId ? -1 : id;
}

void UIContext::pack() {
}

void UIContext::onClick(glm::vec2 pos) {
	std::cout << "click" << std::endl;
	int aa,rootcomponentid;
	if ((aa = findComponent(pos)) != -1) {
		targetId = aa;
		std::cout << instanceData[targetId]->position.x << std::endl;
		instanceData[targetId]->onClick();
	}
}

void UIContext::onDrag(glm::vec2 pos) {
	std::cout << "drag" << std::endl;
}

void UIContext::onRelease(glm::vec2 pos) {
	std::cout << "release" << std::endl;
}

void UIContext::onDoubleClick(glm::vec2 pos) {
	std::cout << "double click" << std::endl;
}
