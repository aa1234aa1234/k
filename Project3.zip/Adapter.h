#pragma once
#include "header.h"
#include "EventHandler.h"



class Adapter {
	EventHandler* eventHandler;
public:
	Adapter() {
		eventHandler->registerEvent(new Event<glm::vec2>("click",&onClick));
		eventHandler->registerEvent(new Event<glm::vec2>("drag", &onDrag));
		eventHandler->registerEvent(new Event<glm::vec2>("release", &onRelease));
	};
	~Adapter() {
		delete eventHandler;
	};
	virtual void onClick(glm::vec2 pos) = 0;
	virtual void onDrag(glm::vec2 pos) = 0;
	virtual void onRelease(glm::vec2 pos) = 0;
};