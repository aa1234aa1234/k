#pragma once
#include "header.h"
#include "EventHandler.h"



class Adapter {
protected:
	EventHandler* eventHandler;
public:
	Adapter() {
		eventHandler = new EventHandler();
		eventHandler->registerEvent(new Event<glm::vec2>("click", std::function<void(glm::vec2)>(std::bind(&Adapter::onClick, this, std::placeholders::_1))));
		eventHandler->registerEvent(new Event<glm::vec2>("drag", std::function<void(glm::vec2)>(std::bind(&Adapter::onDrag, this, std::placeholders::_1))));
		eventHandler->registerEvent(new Event<glm::vec2>("release", std::function<void(glm::vec2)>(std::bind(&Adapter::onRelease, this, std::placeholders::_1))));
		eventHandler->registerEvent(new Event<glm::vec2>("doubleclick", std::function<void(glm::vec2)>(std::bind(&Adapter::onDoubleClick, this, std::placeholders::_1))));
	};
	~Adapter() {
		delete eventHandler;
	};
	virtual void onClick(glm::vec2 pos) = 0;
	virtual void onDrag(glm::vec2 pos) = 0;
	virtual void onRelease(glm::vec2 pos) = 0;
	virtual void onDoubleClick(glm::vec2 pos) = 0;
	void queueEvent(const std::string& id, glm::vec2 pos) {
		eventHandler->queueEvent(id, pos);
	}
	void dispatchEvent() {
		eventHandler->dispatchEvent();
	}
};