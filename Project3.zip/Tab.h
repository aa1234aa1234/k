#pragma once
#include "header.h"
#include "TabView.h"

class Tab : public UIComponent {
	std::string title;
	int id = 0;
	bool active = 0;
	template<typename T, typename K>
	inline bool instanceof(const K& k) {
		return typeid(T).hash_code == typeid(k).hash_code();
	}
	void onClick() {
		if (parentComponent == nullptr) return;
		if (instanceof<TabView*>(parentComponent)) {
			dynamic_cast<TabView*>(parentComponent)->selectedtab = id;
		}
		else {
			return;
		}
	}
public:
	Tab(const glm::vec2& pos, const glm::vec2& size, const int& id) : UIComponent(pos, size) { this->id = id; }
	Tab() : UIComponent() {}
	~Tab() {
		destroy();
	}
	void DrawComponent(Shader* shader) {

	}

};
