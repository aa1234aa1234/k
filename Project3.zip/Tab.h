#pragma once
#include "header.h"
#include "UIComponent.h"
#include "TabView.h"
#include "TextHandler.h"

extern TextHandler* textHandler;

class Tab : public UIComponent {
	std::string title;
	int id = 0;
	bool active = 0;
	glm::vec3* color = new glm::vec3[2]{ glm::vec3(60,60,60), glm::vec3(40,40,40) };;
	template<typename T, typename K>
	inline bool instanceof(const K& k) {
		return typeid(T).hash_code() == typeid(k).hash_code();
	}
	void onClick();
public:
	Tab(const glm::vec2& pos, const glm::vec2& size, const int& id, const char* title) : UIComponent(pos, size) {
		this->id = id; this->title = std::string(title); 
		uielement = { position,color[active],size,1 };
		textHandler->addText(position.x+5, position.y+2, title);
	}
	Tab() : UIComponent() {}
	~Tab() {
		destroy();
	}
	Element DrawComponent() override;
	void Update() override;
};
