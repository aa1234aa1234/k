#pragma once
#include "header.h"
class AppInfo {
public:
	inline glm::vec2 getSize() {
		int width, height;
		glm::vec2 size = glm::vec2();
		
	}
};