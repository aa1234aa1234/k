#include "header.h"
#include "FrameBuffer.h"
#include "Mesh.h"
#include "Shader.h"
#include "ModelImporter.h"
#include <stb/stb_image.h>
#include "Camera.h"
#include "Scene.h"
#include "UIComponent.h"
#include "UIContext.h"
#include "SceneView.h"

using namespace std;


class Point {
    double x, y;
public:
    Point() : x(0), y(0) {};
    Point(double a, double b) : x(a), y(b) {};
    double getX() { return x; }
    double getY() { return y; }
    void setX(double a) { x = a; }
    void setY(double a) { y = a; }
};

Point pos;
Point pos2;
Point lastpos;
GLFWwindow* window;
Scene* scene;
UIContext* context;
int windowwidth, windowheight;

//FrameBuffer framebuffer = FrameBuffer();

float deltatime = 0.0f, lastframe = 0.0f;

bool firstmouse = true;
void convertpt(GLFWwindow* window, Point& pos);
void drawRect(int framebuffer1, Point& pos, Point& pos2);



std::ostream& operator<<(std::ostream& stream, glm::vec4& vector) {
    stream << vector.x << ' ' << vector.y << ' ' << vector.z << ' ' << vector.w << std::endl;
    return stream;
}

std::ostream& operator<<(std::ostream& stream, glm::vec3& vector) {
    stream << vector.x << ' ' << vector.y << ' ' << vector.z << std::endl;
    return stream;
}


void init() {
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //framebuffer.init(width, height);
    //framebuffer.bind();
    //glClearColor(0.5, 1.0, 1.0, 1.0);
    //glClear(GL_COLOR_BUFFER_BIT);
    //framebuffer.unbind();
    lastpos = Point(width / 2, height / 2);

}


void keypress(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) glfwSetWindowShouldClose(window, true);
    scene->getCamera()->moveCamera(window, deltatime);
}

int main(void)
{

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(1700, 900, "this is a title", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }
    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    gladLoadGL(glfwGetProcAddress);
    glfwGetFramebufferSize(window, &windowwidth, &windowheight);
    glViewport(0, 0, windowwidth, windowheight);
    
    glEnable(GL_DEPTH_TEST);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    stbi_set_flip_vertically_on_load(true);
    scene = new Scene(windowwidth, windowheight);
    context = new UIContext();
    init();
    //glfwSetWindowMonitor(window, glfwGetPrimaryMonitor(), 0, 0, 1920, 1080, 0);
    //glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    /*glfwSetKeyCallback(window, [](GLFWwindow* window, int key, int scancode, int action, int mods) {

        });*/
    glfwSetScrollCallback(window, [](GLFWwindow* window, double xoffset, double yoffset) {
        scene->getCamera()->fov -= yoffset * 5;
    });
    glfwSetWindowSizeCallback(window, [](GLFWwindow* window, int width, int height) {

        glfwSwapBuffers(window);
        windowwidth = width; windowheight = height;
        glViewport(0, 0, width, height);
        scene->getCamera()->projection = glm::perspective(glm::radians(scene->getCamera()->fov), (float)width / (float)height, 0.1f, 100.0f);
        scene->resizeSceneBuffer(width, height);
        context->setSize(width, height);
        std::cout << width << ' ' << height << std::endl;
        });

    glfwSetCursorPosCallback(window, [](GLFWwindow* window, double xpos, double ypos) {
        if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_1) != 1) {
            return;
        }
        if (firstmouse) {
            lastpos.setX(xpos); lastpos.setY(ypos);
            firstmouse = false;
        }
        Point offset(xpos - lastpos.getX(), lastpos.getY() - ypos);
        lastpos.setX(xpos); lastpos.setY(ypos);
        float sensitivity = 0.2f;
        offset.setX(offset.getX() * sensitivity);
        offset.setY(offset.getY() * sensitivity);
        scene->getCamera()->yaw += offset.getX();
        scene->getCamera()->pitch += offset.getY();
        if (scene->getCamera()->pitch > 89.0f) scene->getCamera()->pitch = 89.0f;
        if (scene->getCamera()->pitch < -89.0f) scene->getCamera()->pitch = -89.0f;
        glm::vec3 direction, direction2;
        direction.x = cos(glm::radians(scene->getCamera()->yaw)) * cos(glm::radians(scene->getCamera()->pitch));
        direction.y = sin(glm::radians(scene->getCamera()->pitch));
        direction.z = sin(glm::radians(scene->getCamera()->yaw)) * cos(glm::radians(scene->getCamera()->pitch));
        direction = glm::normalize(direction);
        direction2.x = cos(glm::radians(scene->getCamera()->yaw)) * cos(glm::radians(0.0f));
        direction2.y = sin(glm::radians(0.0f));
        direction2.z = sin(glm::radians(scene->getCamera()->yaw)) * cos(glm::radians(0.0f));
        direction2 = glm::normalize(direction2);
        scene->getCamera()->camerafront = direction;
        scene->getCamera()->cameradirection = direction2;
        });
    glfwSwapInterval(1);
    float vertices[] = {
        0.5f,0.5f,0.0f,1.0f,1.0f,
        0.5f,-0.5f,0.0f,1.0f,0.0f,
        -0.5f,-0.5f,0.0f,0.0f,0.0f,
        -0.5f,0.5f,0.0f,0.0f,1.0f
    };
    
    unsigned int indices[] = {
        0,1,3,
        1,2,3
    };
    unsigned int screenvbo, screenvao, screenebo;
    glGenVertexArrays(1, &screenvao);
    glGenBuffers(1, &screenvbo);
    glGenBuffers(1, &screenebo);
    glBindVertexArray(screenvao);
    glBindBuffer(GL_ARRAY_BUFFER, screenvbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, screenebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    ModelImporter* importer = new ModelImporter();
    
    Shader* objectshader = new Shader("shader/vertex.glsl", "shader/frag.glsl");
    
    
    

    
    
    /* Loop until the user closes the window */
    Object obj = Object(importer->loadModel("models/spider.obj"));
    //scene->addObject(obj);
    //obj.Draw(objectshader);
    
    int browhy = 0;
    context->setSize(windowwidth, windowheight);
    context->add(new UIComponent(glm::vec2(0,0),glm::vec2(400.0,200.0)),1);
    SceneView* sceneview = new SceneView();
    sceneview->addScene(scene);
    context->add(sceneview,2);
   
    context->pack();
    while (!glfwWindowShouldClose(window))
    {
        float currentFrame = glfwGetTime();
        deltatime = currentFrame - lastframe;
        lastframe = currentFrame;
        keypress(window); 
        scene->getCamera()->projection = glm::perspective(glm::radians(scene->getCamera()->fov), (float)windowwidth / (float)windowheight, 0.1f, 100.0f);
        /* Render here */
        sceneview->renderScene();
        glDisable(GL_DEPTH_TEST);
        //glClearColor(1.0,0.1,0.1,1.0);
        glClearColor(0.45, 0.45, 0.45, 1.0);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        
        /*objectshader->use();
        glBindVertexArray(screenvao);
        glBindTexture(GL_TEXTURE_2D, scene->getSceneTexture());
        
        glm::mat4 wah = glm::mat4(1.0);
        wah = glm::translate(wah, glm::vec3(0.0, 0.0, 0.0));
        wah = glm::scale(wah, glm::vec3(1.0, 1.0, 0.0));
        
        glUniformMatrix4fv(glGetUniformLocation(objectshader->getId(), "model"), 1, GL_FALSE, glm::value_ptr(wah));
        
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glBindTexture(GL_TEXTURE_2D, 0);
        glBindVertexArray(0);*/
        context->DrawComponents();
        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }
    glDeleteVertexArrays(1, &screenvao);
    glDeleteBuffers(1, &screenvbo);
    glDeleteBuffers(1, &screenebo);
    delete importer;
    delete context;
    delete objectshader;
    glfwTerminate();
    return 0;
}