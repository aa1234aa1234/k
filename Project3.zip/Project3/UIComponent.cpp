#include "UIComponent.h"

UIComponent::UIComponent(int& x, int& y) {
	position.x = x;
	position.y = y;
	genVertices();
}

UIComponent::~UIComponent() {

}

void UIComponent::genVertices() {
	uielements.push_back({ glm::vec2(1.0,1.0),glm::vec2(0.0,0.0),glm::vec4(0.3,0.3,0.3,1.0) });
	uielements.push_back({ glm::vec2(1.0,-1.0),glm::vec2(0.0,0.0),glm::vec4(0.3,0.3,0.3,1.0) });
	uielements.push_back({ glm::vec2(-1.0,1.0),glm::vec2(0.0,0.0),glm::vec4(0.3,0.3,0.3,1.0) });
	uielements.push_back({ glm::vec2(1.0,-1.0),glm::vec2(0.0,0.0),glm::vec4(0.3,0.3,0.3,1.0) });
	uielements.push_back({ glm::vec2(-1.0,-1.0),glm::vec2(0.0,0.0),glm::vec4(0.3,0.3,0.3,1.0) });
	uielements.push_back({ glm::vec2(-1.0,1.0),glm::vec2(0.0,0.0),glm::vec4(0.3,0.3,0.3,1.0) });
}
