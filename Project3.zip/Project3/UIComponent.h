#pragma once
#include "header.h"
#include "Shader.h"

struct UIElements {
	glm::vec2 position;
	glm::vec2 texcoord;
	glm::vec4 colors;
};

class UIComponent
{
public:
	std::vector<UIElements> uielements;
	glm::vec2 position;
	glm::vec2 texcoords;
	glm::vec2 size;
	glm::vec4 color;
	UIComponent(int& x, int& y);
	~UIComponent();
	virtual void genVertices();
};

