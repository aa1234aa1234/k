#include "Model.h"

Model::~Model() {

}

void Model::Draw(Shader& shader) {
	for (auto& p : meshes) {
		p.Draw(shader);
	}
}