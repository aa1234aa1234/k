#include "Scene.h"

Scene::Scene(int& w, int& h) {
	sceneBuffer.init(w, h);
}

Scene::~Scene() {
	delete camera;
}

void Scene::renderScene() {
	sceneShader.use();
	sceneBuffer.bind();
	glUniformMatrix4fv(glGetUniformLocation(sceneShader.getId(), "projection"), 1, GL_FALSE, glm::value_ptr(camera->projection));
	glUniformMatrix4fv(glGetUniformLocation(sceneShader.getId(), "view"), 1, GL_FALSE, glm::value_ptr(camera->view));
	for (auto& p : objects) {
		glUniformMatrix4fv(glGetUniformLocation(sceneShader.getId(), "model"), 1, GL_FALSE, glm::value_ptr(p.getModelMatrix()));
		p.Draw(sceneShader);
	}
	sceneBuffer.unbind();
}
