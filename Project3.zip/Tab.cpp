#include "Tab.h"

void Tab::onClick() {
	if (parentComponent == nullptr) return;
	if (instanceof<TabView*>(parentComponent)) {
		dynamic_cast<TabView*>(parentComponent)->selectedtab = id;
	}
	else {
		return;
	}
}

std::vector<Element*> Tab::DrawComponent() {
	return uielements;
}

void Tab::Update() {

	UIComponent::Update();
}