#include "Tab.h"

int Tab::onClick() {
	if (parentComponent == nullptr) return -1;
	if (instanceof<TabView*>(parentComponent)) {
		dynamic_cast<TabView*>(parentComponent)->selectedtab = id;
		parentComponent->Update();
		return UIComponent::onClick();
	}
	else {
		return componentId;
	}
}

Element Tab::DrawComponent() {
	uielement = { position,color[active],size,1 };
	//textHandler->draw(position.x, position.y, title);
	return uielement;
}

void Tab::Update() {
	uielement = { position,color[active],size,1 };
	UIComponent::Update();
}