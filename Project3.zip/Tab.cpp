#include "Tab.h"

void Tab::onClick() {
	if (parentComponent == nullptr) return;
	if (instanceof<TabView*>(parentComponent)) {
		dynamic_cast<TabView*>(parentComponent)->selectedtab = id;
	}
	else {
		return;
	}
}

Element Tab::DrawComponent() {
	uielement = { position,color[active],size,1 };
	textHandler->draw(position.x, position.y, title);
	return uielement;
}

void Tab::Update() {

	UIComponent::Update();
}