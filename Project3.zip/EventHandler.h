#pragma once
#include "header.h"
#include <functional>
#include <typeindex>
#include <queue>
#include <map>

template<typename ...Args>
class Event;

class IEvent {
public:
	virtual std::string& getId() = 0;
	virtual std::type_index getType() = 0;
	template<typename ...Args>
	Event<Args...>* get() {
		return dynamic_cast<Event<Args...>*>(this);
	}
};

template<typename ...Args>
class Event : public IEvent {
	std::string eventId;
	std::function<void(Args...)> const func;
public:
	Event(const std::string& id, std::function<void(Args...)> func) : eventId(id), func(func) {

	}
	~Event() {}

	virtual std::string& getId() override { return eventId; }
	virtual std::type_index getType() override {
		return typeid(Event<Args...>);
	}
	void callEvent(Args... args) {
		this->func(args...);
	}
};

class EventHandler
{
	std::map<std::string, std::vector<IEvent*>> eventList;
	std::queue<std::function<void()>> eventQueue;
	
public:
	EventHandler() {}
	~EventHandler() {
		for (auto& k : eventList) {
			for (auto& p : k.second) {
				delete p;
			}
			k.second.clear();
		}
	}

	void registerEvent(IEvent* event) {
		eventList[event->getId()].push_back(event);
	}

	template<typename ...Args>
	void callEvent(const std::string& id, Args... args) {
		for (auto& p : eventList[id]) {
			
			Event<Args...>* event = p->get<Args...>();
			if (event == nullptr) {
				std::cout << "Registered type: " << p->getType().name() << ", Requested: " << typeid(Event<Args...>).name() << std::endl;
				std::cout << "nullptr" << std::endl;
				return;
			}
			event->callEvent(args...);
		}
	}

	template<typename ...Args>
	void queueEvent(const std::string& id, Args... args) {
		eventQueue.push([this, id, args...]() { this->callEvent<Args...>(id, args...); });
	}

	void dispatchEvent() {
		if (eventQueue.size()) {
			eventQueue.front()();
			eventQueue.pop();
		}
	}
};

