#include "TabView.h"

void TabView::init() {
	isDraggable = true;
	const char* a[] = { "Game","Scene" };
	for (int i = 0; i < TAB_NUM; i++) {
		addChildComponent(new Tab(glm::vec2(position.x + TAB_WIDTH * i, position.y), glm::vec2(TAB_WIDTH, TAB_HEIGHT), i, a[i]));
	}
	uielement = { position,color,size,0 };
}

int TabView::Update() {
	for (int i = 0; i < TAB_NUM; i++) {
		if (i != selectedtab) dynamic_cast<Tab*>(childComponents[i])->setActive(0);
	}
	UIComponent::Update();
	std::cout << childComponents[TAB_NUM-1]->getComponentId() << std::endl;
	return childComponents[TAB_NUM-1]->getComponentId();
}

Element TabView::DrawComponent() {
	uielement = { position,color,size, 0};
	for (auto& p : childComponents) p->DrawComponent();
	return uielement;
}