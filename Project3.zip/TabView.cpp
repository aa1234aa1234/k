#include "TabView.h"

void TabView::init() {
	childComponents.reserve(childComponents.size() + TAB_NUM);
	const char* a[] = { "Game","Scene" };
	for (int i = 0; i < TAB_NUM; i++) {
		childComponents.emplace_back(new Tab(glm::vec2(position.x + TAB_WIDTH * i, position.y), glm::vec2(TAB_WIDTH, TAB_HEIGHT), i, a[i]));
	}
}

std::vector<Element*> TabView::DrawComponent() {
	for (auto& p : childComponents) {
		std::vector<Element*> v = p->DrawComponent();
		uielements.insert(uielements.end(),v.begin(),v.end());
	}
}