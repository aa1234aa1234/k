#include "TabView.h"

void TabView::init() {
	const char* a[] = { "Game","Scene" };
	for (int i = 0; i < TAB_NUM; i++) {
		addChildComponent(new Tab(glm::vec2(position.x + TAB_WIDTH * i, position.y), glm::vec2(TAB_WIDTH, TAB_HEIGHT), i, a[i]));
	}
	uielement = { position,color,size,0 };
}

Element TabView::DrawComponent() {
	uielement = { position,color,size, 0};
	for (auto& p : childComponents) p->DrawComponent();
	return uielement;
}