#pragma once
#include "header.h"
#include "UIComponent.h"
#include "Tab.h"

class TabView : public UIComponent {
	int TAB_NUM = 2;
	int TAB_WIDTH = 100, TAB_HEIGHT = 25;
	std::vector<Element*> uielements;
	glm::vec3 color = glm::vec3(40, 40, 40);
public:
	int selectedtab = 0;
	TabView() : UIComponent() {
		init();
	}
	TabView(const glm::vec2& pos, const glm::vec2& size) : UIComponent(pos, size) {
		init();
	}
	~TabView() {
		destroy();
	}
	void init();
	std::vector<Element*> DrawComponent() override;
};