#pragma once
#include "header.h"
#include "UIComponent.h"
#define TAB_NUM 2

class TabView : public UIComponent {
	int selectedtab = 0;
	glm::vec2 tabsize = glm::vec2(0.0, 0.0);
	glm::vec3 color = glm::vec3(0, 0, 0);
public:
	TabView() : UIComponent() {
		for (int i = 0; i < TAB_NUM; i++) {
			childComponents.reserve(childComponents.size() + 1);
			//childComponents.emplace_back(new Tab(glm::vec2());
		}
	}
	TabView(const glm::vec2& pos, const glm::vec2& size) : UIComponent(pos, size) {}
	~TabView() {
		destroy();
	}
};

class Tab : public UIComponent {
	std::string title;
public:
	Tab(const glm::vec2& pos, const glm::vec2& size) : UIComponent(pos,size) {
		
	}
	~Tab() {
		destroy();
	}
	void DrawComponent(Shader* shader) {

	}
	void onClick() {
	}
};