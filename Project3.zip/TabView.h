#pragma once
#include "header.h"
#include "UIComponent.h"

class TabView : public UIComponent {
	
public:
};

class UITab {
	int id = 0;
	std::string title;
	std::vector<UIElements> vertices;
public:
	UITab(int& id) : id(id) {
	}

	void setTitle(const char* title) {
		this->title = title;
	}

	virtual void onClick(int& idx) {
		idx = id;
	}

	void draw() {
	}
};