#pragma once
#include "header.h"
#include "UIComponent.h"
#include "Tab.h"


class TabView : public UIComponent {
	int TAB_NUM = 2;
	int TAB_WIDTH = 100, TAB_HEIGHT = 25;
	glm::vec3 color = glm::vec3(0, 0, 0);
public:
	int selectedtab = 0;
	TabView() : UIComponent() {
		init();
	}
	TabView(const glm::vec2& pos, const glm::vec2& size) : UIComponent(pos, size) {
		init();
	}
	~TabView() {
		destroy();
	}
	void init() {
		childComponents.reserve(childComponents.size() + TAB_NUM);
		for (int i = 0; i < TAB_NUM; i++) {
			childComponents.emplace_back(new Tab(glm::vec2(position.x + TAB_WIDTH * i, position.y), glm::vec2(TAB_WIDTH, TAB_HEIGHT), i));
		}
	}
	void DrawComponent(Shader* shader) {
		for (auto& p : childComponents) {
			p->DrawComponent(shader);
		}
	}
};