#pragma once
#include "header.h"
#include "Mesh.h"

class Model
{
	std::vector<Mesh> meshes;
	glm::mat4 scale = glm::mat4(1.0f);
	glm::vec3 position;
public:
	Model(std::vector<Mesh> meshes) : meshes(std::move(meshes)) {}
	~Model();
	void Draw(Shader& shader);
};

