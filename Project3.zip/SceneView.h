#pragma once
#include "header.h"
#include "UIComponent.h"
#include "Scene.h"

class SceneView : public UIComponent {
	std::vector<Scene*> scenes;
	int selectedscene = 0;
public:
	SceneView();
	~SceneView();

	void addScene(Scene* scene) {
		scenes.reserve(scenes.size() + 1);
		scenes.emplace_back(scene);
	}

	virtual void genVertices() override {
		generateQuad();
		for (int i = 0; i < scenes.size(); i++) generateQuad();
	}

	virtual void DrawComponent(Shader* shader) override {
		
	}
};