#pragma once
#include "header.h"
#include "UIComponent.h"
#include "Scene.h"

class SceneView : public UIComponent {

	

	std::vector<Scene*> scenes;
	std::vector<UIElements> sceneviewtabs;
	int selectedscene = 0;
public:
	SceneView() : UIComponent() {
		genVertices();
	}

	~SceneView() {
		for (auto& p : scenes) {
			delete p;
		}
		scenes.clear();
	}

	void addScene(Scene* scene) {
		scenes.reserve(scenes.size() + 1);
		scenes.emplace_back(scene);
	}

	void renderScene() {
		scenes[selectedscene]->renderScene();
	}

	virtual void genVertices() override {
		
		generateQuad();
		for (int i = 0; i < scenes.size(); i++) {
			sceneviewtabs.push_back({ glm::vec2(1.0,1.0),glm::vec2(1.0,1.0),glm::vec3(0.3,0.3,0.3) });
			sceneviewtabs.push_back({ glm::vec2(1.0,0.0),glm::vec2(1.0,-1.0),glm::vec3(0.3,0.3,0.3) });
			sceneviewtabs.push_back({ glm::vec2(0.0,1.0),glm::vec2(-1.0,1.0),glm::vec3(0.3,0.3,0.3) });
			sceneviewtabs.push_back({ glm::vec2(1.0,0.0),glm::vec2(1.0,-1.0),glm::vec3(0.3,0.3,0.3) });
			sceneviewtabs.push_back({ glm::vec2(0.0,0.0),glm::vec2(-1.0,-1.0),glm::vec3(0.3,0.3,0.3) });
			sceneviewtabs.push_back({ glm::vec2(0.0,1.0),glm::vec2(-1.0,1.0),glm::vec3(0.3,0.3,0.3) });
		}
	}

	virtual void DrawComponent(Shader* shader) override {
		glm::mat4 matrix = glm::mat4(1.0);
		matrix = glm::translate(matrix, glm::vec3(0.0, 0.0, 0.0));
		matrix = glm::scale(matrix, glm::vec3(1000.0, 800.0, 0.0));
		glBindTexture(GL_TEXTURE_2D, scenes[selectedscene]->getSceneTexture());
		glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "model"), 1, GL_FALSE, glm::value_ptr(matrix));
		glUniform1i(glGetUniformLocation(shader->getId(), "a"), 1);
		
		glDrawArrays(GL_TRIANGLES, 0, uielements.size());
		glBindTexture(GL_TEXTURE_2D, 0);
		glUniform1i(glGetUniformLocation(shader->getId(), "a"), 0);
		for (auto& p : sceneviewtabs) {
			//glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(UIElements) * 6, p->uielements.data());
		}
	}
};