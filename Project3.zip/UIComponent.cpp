#include "UIComponent.h"

UIComponent::UIComponent(const glm::vec2& pos) {
	position.x = pos.x;
	position.y = pos.y;
	genVertices();
}

UIComponent::~UIComponent() {

}

void UIComponent::genVertices() {
    uielements.push_back({ glm::vec2(0.5,0.5),glm::vec2(1.0,1.0),glm::vec3(0.3,0.3,0.3) });
    uielements.push_back({ glm::vec2(0.5,-0.5),glm::vec2(1.0,-1.0),glm::vec3(0.3,0.3,0.3) });
    uielements.push_back({ glm::vec2(-0.5,0.5),glm::vec2(-1.0,1.0),glm::vec3(0.3,0.3,0.3) });
    uielements.push_back({ glm::vec2(0.5,-0.5),glm::vec2(1.0,-1.0),glm::vec3(0.3,0.3,0.3) });
    uielements.push_back({ glm::vec2(-0.5,-0.5),glm::vec2(-1.0,-1.0),glm::vec3(0.3,0.3,0.3) });
    uielements.push_back({ glm::vec2(-0.5,0.5),glm::vec2(-1.0,1.0),glm::vec3(0.3,0.3,0.3) });
}
