#include "UIComponent.h"

UIComponent::UIComponent(const glm::vec2& pos, const glm::vec2& size) {
	position.x = pos.x;
	position.y = pos.y;
    this->size.x = size.x;
    this->size.y = size.y;
	genVertices();
}

UIComponent::UIComponent() {

}

UIComponent::~UIComponent() {

}

void UIComponent::genVertices() {
    generateQuad();
}

void UIComponent::DrawComponent(Shader* shader) {
    glm::mat4 model = glm::mat4(1.0);
    model = glm::translate(model, glm::vec3(position.x, position.y, 0.0));
    model = glm::scale(model, glm::vec3(size.x, size.y, 0.0));
    glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "model"), 1, GL_FALSE, glm::value_ptr(model));
    glDrawArrays(GL_TRIANGLES, 0, uielements.size());
}

void UIComponent::generateQuad() {
    uielements.push_back({ glm::vec2(1.0,1.0),glm::vec2(1.0,1.0),glm::vec3(0.45, 0.45, 0.45) });
    uielements.push_back({ glm::vec2(1.0,-1.0),glm::vec2(1.0,-1.0),glm::vec3(0.45, 0.45, 0.45) });
    uielements.push_back({ glm::vec2(-1.0,1.0),glm::vec2(-1.0,1.0),glm::vec3(0.45, 0.45, 0.45) });
    uielements.push_back({ glm::vec2(-1.0,-1.0),glm::vec2(-1.0,-1.0),glm::vec3(0.45, 0.45, 0.45) });
    uielements.push_back({ glm::vec2(1.0,-1.0),glm::vec2(1.0,-1.0),glm::vec3(0.45, 0.45, 0.45) });
    uielements.push_back({ glm::vec2(-1.0,1.0),glm::vec2(-1.0,1.0),glm::vec3(0.45, 0.45, 0.45) });
}
