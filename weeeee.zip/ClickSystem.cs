﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class ClickSystem : SignatureSystem
    {
        private Int32 selectedEntity = -1;

        public ClickSystem() { Initialize(); }

        public void Initialize()
        {
            Bitset signature = new Bitset();
            signature[Coordinator.getInstance().GetComponentType<Renderable>()] = true;
            signature[Coordinator.getInstance().GetComponentType<Interactable>()] = true;
            Coordinator.getInstance().SetSystemSignature<ClickSystem>(signature);
        }

        public void Update()
        {
            Coordinator coordinator = Coordinator.getInstance();
            if (selectedEntity != -1)
            {
                switch (Input.getInstance().getEventType())
                {
                    case Input.EventType.MOUSEDRAG:
                        coordinator.GetComponent<Interactable>(selectedEntity).onDrag();
                        break;
                    case Input.EventType.MOUSEUP:
                        coordinator.GetComponent<Interactable>(selectedEntity).onRelease();
                        selectedEntity = -1;
                        coordinator.RemoveComponent<Selected>(selectedEntity);
                        break;
                }
                return;
            }
            for(int i = entities.Count - 1; i>=0; i--)
            {
                int p = entities.ToArray()[i];
                if (coordinator.GetComponent<Renderable>(p).UVRect.Contains(Input.getInstance().getMousePos()) && Input.getInstance().getEventType() == Input.EventType.MOUSEDOWN)
                {
                    Console.WriteLine("test" + Input.getInstance().getEventType());
                    Console.WriteLine(coordinator.EntityHasComponent<CardProperties>(p));
                    if(coordinator.EntityHasComponent<CardProperties>(p))
                    {
                        if (coordinator.GetComponent<CardProperties>(p).isRevealed)
                        {
                            selectedEntity = p;
                            coordinator.AddComponent(selectedEntity, new Selected{ });
                        }
                    }
                    coordinator.GetComponent<Interactable>(p).onClick();
                    return;
                }
            }
        }
    }
}
