﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class ClickSystem : SignatureSystem
    {
        private Int32 selectedEntity = -1;

        public ClickSystem() { Initialize(); }

        public void Initialize()
        {
            Bitset signature = new Bitset();
            signature[Coordinator.getInstance().GetComponentType<Renderable>()] = true;
            signature[Coordinator.getInstance().GetComponentType<Interactable>()] = true;
            Coordinator.getInstance().SetSystemSignature<ClickSystem>(signature);
        }

        public void Update()
        {
            Coordinator coordinator = Coordinator.getInstance();
            if (selectedEntity != -1)
            {
                switch (Input.getInstance().getEventType())
                {
                    case Input.EventType.MOUSEDRAG:
                        coordinator.GetComponent<Interactable>(selectedEntity).onDrag();
                        break;
                    case Input.EventType.MOUSEUP:
                        coordinator.GetComponent<Interactable>(selectedEntity).onRelease();
                        coordinator.RemoveComponent<Selected>(selectedEntity);
                        selectedEntity = -1;
                        break;
                }
                return;
            }
            if (Input.getInstance().getEventType() != Input.EventType.MOUSEDOWN) return;
            for(int i = 0; i<entities.Count; i++)
            {
                int p = entities.ToArray()[i];
                bool flag = false;
                if(coordinator.EntityHasComponent<Child>(p))
                {
                    while (coordinator.EntityHasComponent<Child>(p))
                    {
                        int a = coordinator.GetComponent<Child>(p).value;
                        //Console.WriteLine(a);
                        if (coordinator.GetComponent<Renderable>(a).UVRect.Contains(Input.getInstance().getMousePos())) { flag = true; p = a; }
                        else break;
                    }
                }

                if (flag || coordinator.GetComponent<Renderable>(p).UVRect.Contains(Input.getInstance().getMousePos()))
                {
                    Console.WriteLine("test" + Input.getInstance().getEventType());

                    Console.WriteLine(coordinator.EntityHasComponent<CardProperties>(p));
                    if (coordinator.EntityHasComponent<CardProperties>(p))
                    {
                        if (coordinator.GetComponent<CardProperties>(p).isRevealed)
                        {
                            selectedEntity = p;
                            coordinator.AddComponent(selectedEntity, new Selected { });
                        }
                    }
                    coordinator.GetComponent<Interactable>(p).onClick();
                    return;
                }

            }
        }
    }
}
