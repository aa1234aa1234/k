﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class ClickSystem : SignatureSystem
    {
        private Int32 selectedEntity = -1;

        public ClickSystem() { Initialize(); }

        public void Initialize()
        {
            Bitset signature = new Bitset();
            signature[Coordinator.getInstance().GetComponentType<Renderable>()] = true;
            signature[Coordinator.getInstance().GetComponentType<CardProperties>()] = true;
            Coordinator.getInstance().SetSystemSignature<ClickSystem>(signature);
        }

        public void Update()
        {
            Coordinator coordinator = Coordinator.getInstance();
            if (selectedEntity != -1)
            {
                switch (Input.getInstance().getEventType())
                {
                    case Input.EventType.MOUSEDRAG:
                        coordinator.GetComponent<CardProperties>(selectedEntity).onDrag();
                        break;
                    case Input.EventType.MOUSEUP:
                        coordinator.GetComponent<CardProperties>(selectedEntity).onRelease();
                        selectedEntity = -1;
                        break;
                }
                return;
            }
            foreach (var p in entities)
            {
                if (coordinator.GetComponent<Renderable>(p).UVRect.Contains(Input.getInstance().getMousePos()) && Input.getInstance().getEventType() == Input.EventType.MOUSEDOWN)
                {
                    Console.WriteLine("test" + Input.getInstance().getEventType());
                    selectedEntity = p;
                    coordinator.GetComponent<CardProperties>(p).onClick();
                }
            }
        }
    }
}
