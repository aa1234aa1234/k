﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    class Bitset
    {
        public ulong bits = 0 | (1UL << 18);
        public int Length;
        public ulong Mask => (1UL << Length) - 1;

        public Bitset(int length)
        {
            this.Length = length;
            bits = 0 | (0UL << length);
        }

        public Bitset()
        {

        }

        public bool this[int idx]
        {
            get => (bits & (1UL << idx)) != 0;
            set
            {
                if (value) bits |= 1UL << idx;
                else bits &= ~(1UL << idx);
            }
        }

        public static Bitset operator &(Bitset a, Bitset b) => new() { bits = a.bits & b.bits, Length = a.Length };
        public static bool operator ==(Bitset a, Bitset b) => ReferenceEquals(a, b) || (a?.bits == b?.bits);
        public static bool operator !=(Bitset a, Bitset b) => !(a == b);
        public static Bitset operator +(Bitset a, Bitset b) => new() { bits = (a.bits << b.Length) | b.bits, Length = a.Length + b.Length };
        public static Bitset operator ^(Bitset a, Bitset b) => new() { bits = a.bits ^ b.bits, Length = a.Length };
        public static Bitset operator <<(Bitset a, int cnt) => new() { bits = (a.bits << cnt) & a.Mask, Length = a.Length };
        public static Bitset operator >>(Bitset a, int cnt) => new() { bits = (a.bits >> cnt) & a.Mask, Length = a.Length };
    }
}
