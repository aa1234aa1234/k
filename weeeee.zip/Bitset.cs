﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    class Bitset
    {
        public ulong bits = 0 | (1UL << 18);

        public bool this[int idx]
        {
            get => (bits & (1UL << idx)) != 0;
            set
            {
                if (value) bits |= 1UL << idx;
                else bits &= ~(1UL << idx);
            }
        }

        public static Bitset operator &(Bitset a, Bitset b) => new() { bits = a.bits & b.bits };
        public static bool operator ==(Bitset a, Bitset b) => ReferenceEquals(a, b) || (a?.bits == b?.bits);
        public static bool operator !=(Bitset a, Bitset b) => !(a == b);
    }
}
