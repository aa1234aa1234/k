﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class ImageUtils
    {
        private static ImageUtils instance;
        public Image atlas = new Bitmap(global::weeeee.Properties.Resources.cards);
        public Image background = new Bitmap(global::weeeee.Properties.Resources.carpet);

        public static ImageUtils getInstance()
        {
            if(instance == null) instance = new ImageUtils();
            return instance;
        }

        public Image getAtlas() { return atlas; }
        public Image getBackground() { return background; }
    }
}
