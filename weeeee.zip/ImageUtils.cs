﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class ImageUtils
    {
        private static ImageUtils instance;
        private Image[,] cards = new Image[13, 5];
        public Image atlas = new Bitmap(global::weeeee.Properties.Resources.cards);
        public Image background = new Bitmap(global::weeeee.Properties.Resources.carpet);

        public static ImageUtils getInstance()
        {
            if(instance == null) instance = new ImageUtils();
            return instance;
        }

        public ImageUtils()
        {
            for(int i = 0; i<13; i++)
            {
                for(int j = 0; j<5; j++)
                {
                    cards[i, j] = new Bitmap(109, 153);
                    Graphics.FromImage(cards[i, j]).DrawImage(atlas, 0, 0, new Rectangle(i * 109 + 19 * i, 153 * j + 13 * j, 109, 153), GraphicsUnit.Pixel);
                }
            }
        }

        public Image getAtlas() { return atlas; }
        public Image getBackground() { return background; }
        public Image getCardBitmap(int x, int y) { return cards[x, y]; }
    }
}
