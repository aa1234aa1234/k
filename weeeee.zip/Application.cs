﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class Application
    {
        private ComponentManager componentManager = new ComponentManager();

        public Application() { }

        public void Initialize()
        {
            componentManager.RegisterComponent<Parent>();
            componentManager.RegisterComponent<Child>();
            componentManager.RegisterComponent<Renderable>();

            
        }

        public void run()
        {
            
        }

        public void render(object sender, PaintEventArgs e)
        {

        }
    }
}
