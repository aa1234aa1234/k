﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

using Entity = System.Int32;

namespace weeeee
{
    internal class Application
    {

        private Coordinator coordinator = Coordinator.getInstance();

        private List<Node> rootNodes = new();

        private RenderQueueUpdate renderQueueUpdate;
        private RenderSystem renderSystem = new();
        private ClickSystem clickSystem;

        public Application() { }

        public void Initialize()
        {
            coordinator.RegisterComponent<Root>();
            coordinator.RegisterComponent<Renderable>();
            coordinator.RegisterComponent<Parent>();
            coordinator.RegisterComponent<Interactable>();
            coordinator.RegisterComponent<CardProperties>();
            coordinator.RegisterComponent<Child>();
            coordinator.RegisterComponent<Selected>();


            renderQueueUpdate = coordinator.RegisterSystem<RenderQueueUpdate>();
            clickSystem = coordinator.RegisterSystem<ClickSystem>();

            //CreateNode((int)CardType.CLUBS, 4);
            CardPileA cardpile = new (new Point(250,50), CardPileA.Type.PILE), cardpile2 = new CardPileA(cardpile, new Point(50, 50));
            rootNodes.Add(cardpile2);
            rootNodes.Add(cardpile);
            cardpile2.AddNode(CreateNode((int)CardType.CLUBS, 4, new Point()));
            cardpile2.AddNode(CreateNode((int)CardType.CLUBS, 5, new Point()));
            cardpile2.AddNode(CreateNode((int)CardType.CLUBS, 6, new Point()));
            cardpile2.AddNode(CreateNode((int)CardType.CLUBS, 7, new Point()));
            CardPileB cardpileB = new(new Point(250, 300));
            cardpileB.AddNode(CreateNode((int)CardType.DIAMONDS, 8, new Point()));
            rootNodes.Add(cardpileB);
        }

        private Entity CreateNode(int type, int num, Point pos, Entity parent = -1)
        {
            Entity node = coordinator.CreateEntity(num,type, pos);
            //coordinator.AddComponent(node, new Renderable(new Rectangle(num*109+19*num, 153*type+13*type, 109, 153), new Rectangle(100,100,109,153)));
            //coordinator.AddComponent(node, new CardProperties(num, type));

            var properties = coordinator.GetComponent<CardProperties>(node);
            var interactable = coordinator.GetComponent<Interactable>(node);
            var renderable = coordinator.GetComponent<Renderable>(node);
            interactable.onClick = new Interactable.Click(() => {
                if(!properties.isRevealed)
                {
                    if (coordinator.GetComponent<Child>(node).value != 0) return;
                    renderable.ImageUV.X = properties.num * 109 + 19 * properties.num;
                    renderable.ImageUV.Y = (int)properties.cardType * 153 + (int)properties.cardType * 13;
                    properties.isRevealed = !properties.isRevealed;
                }
            });
            interactable.onDrag = new Interactable.Drag(() => {
                if (!properties.isRevealed) return;
                renderable.UVRect.X -= Input.getInstance().getMouseDelta().X;
                renderable.UVRect.Y -= Input.getInstance().getMouseDelta().Y;
                Entity child;
                if(coordinator.EntityHasComponent<Child>(node) && (child= coordinator.GetComponent<Child>(node).value) != 0)
                {
                    coordinator.GetComponent<Interactable>(child).onDrag();
                }
                //Console.WriteLine(renderable.UVRect);
                //Console.WriteLine(Input.getInstance().getMouseDelta());
            });
            interactable.onRelease = new Interactable.Release(() =>
            {
                Stack<int> stack = new Stack<int>();
                foreach (var p in rootNodes)
                {
                    if (!Coordinator.getInstance().GetComponent<Root>(p.getId()).CheckBounds(renderable.UVRect) || p.getId() == Coordinator.getInstance().GetComponent<Parent>(node).value) continue;
                    Entity child = node;
                    if (!Coordinator.getInstance().GetComponent<Root>(p.getId()).Check(node)) continue;
                    stack.Push(node);
                    while (coordinator.EntityHasComponent<Child>(child))
                    {
                        child = coordinator.GetComponent<Child>(node).value;
                        stack.Push(child);
                    }
                    ((CardPile)Coordinator.getInstance().GetEntity(Coordinator.getInstance().GetComponent<Parent>(node).value)).Transfer(ref stack, (CardPile)p);

                }
                coordinator.GetEntity(node).ResetPosition();
                
            });
                //componentManager.AddComponent(node, Parent);
            return node;
        }

        public void run(Form1 form)
        {
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 8;
            timer.Tick += (sender, e) => {
                form.Invalidate();
                Input.getInstance().setEventType(Input.EventType.NONE);
            };
            timer.Start();
        }

        public void handleInput(object sender, MouseEventArgs e)
        {
            clickSystem.Update();
        }

        public void render(object sender, PaintEventArgs e, int width, int height)
        {
            
            e.Graphics.DrawImage(ImageUtils.getInstance().getBackground(), 0, 0, width, height);
            //Console.WriteLine(Input.getInstance().getMousePos());
            //Console.WriteLine(Input.getInstance().getMouseDelta());
            renderQueueUpdate.Update(ref renderSystem.renderQueue);
            renderSystem.Update(e.Graphics);
            
            
        }
    }
}
