﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

using Entity = System.Int32;

namespace weeeee
{
    internal class Application
    {


        private Coordinator coordinator = Coordinator.getInstance();

        private List<Entity> nodes = new List<Entity>();
        private Entity selectedEntity = -1;

        public Application() { }

        public void Initialize()
        {
            coordinator.RegisterComponent<Root>();
            coordinator.RegisterComponent<Renderable>();
            coordinator.RegisterComponent<CardProperties>();

            nodes.Add(CreateNode((int)CardType.CLUBS, 4));
        }

        private Entity CreateNode(int type, int num, Entity parent = -1)
        {
            Entity node = coordinator.CreateEntity();
            coordinator.AddComponent(node, new Renderable(new Rectangle(num*109+19*num, 153*type+13*type, 109, 153), new Rectangle(100,100,109,153)));
            coordinator.AddComponent(node, new CardProperties(num, type));

            var properties = coordinator.GetComponent<CardProperties>(node);
            var renderable = coordinator.GetComponent<Renderable>(node);
            properties.onClick = new CardProperties.Click(() => {
                if(!properties.isRevealed)
                {
                    
                }
            });
            properties.onDrag = new CardProperties.Drag(() => {
                
                renderable.UVRect.X -= Input.getInstance().getMouseDelta().X;
                renderable.UVRect.Y -= Input.getInstance().getMouseDelta().Y;
                //Console.WriteLine(renderable.UVRect);
                //Console.WriteLine(Input.getInstance().getMouseDelta());
            });
            properties.onRelease = new CardProperties.Release(() => { });
            //componentManager.AddComponent(node, Parent);
            return node;
        }

        public void run()
        {
            
        }

        public void handleInput(object sender, MouseEventArgs e)
        {
            if(selectedEntity != -1)
            {
                switch (Input.getInstance().getEventType())
                {
                    case Input.EventType.MOUSEDRAG:
                        coordinator.GetComponent<CardProperties>(selectedEntity).onDrag();
                        break;
                    case Input.EventType.MOUSEUP:
                        coordinator.GetComponent<CardProperties>(selectedEntity).onRelease();
                        selectedEntity = -1;
                        break;
                }
                return;
            }
            foreach(var p in nodes)
            {
                if(coordinator.GetComponent<Renderable>(p).UVRect.Contains(Input.getInstance().getMousePos()) && Input.getInstance().getEventType() == Input.EventType.MOUSEDOWN)
                {
                    Console.WriteLine("test" + Input.getInstance().getEventType());
                    selectedEntity = p;
                    coordinator.GetComponent<CardProperties>(p).onClick();
                }
            }
        }

        public void render(object sender, PaintEventArgs e, int width, int height)
        {
            
            e.Graphics.DrawImage(ImageUtils.getInstance().getBackground(), 0, 0, width, height);
            //Console.WriteLine(Input.getInstance().getMousePos());
            //Console.WriteLine(Input.getInstance().getMouseDelta());
            foreach(var p in nodes)
            {
                coordinator.GetComponent<Renderable>(p).render(e.Graphics);
            }
            ((Form1)sender).Invalidate();
            Input.getInstance().setEventType(Input.EventType.NONE);
        }
    }
}
