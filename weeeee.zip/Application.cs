﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

using Entity = System.Int32;

namespace weeeee
{
    internal class Application
    {
        Bitmap cache;
        Graphics cacheGraphics;

        enum CardPiles
        {
            DECK=0,
            TABLEAU=2,
            FOUNDATION=9
        }

        private Coordinator coordinator = Coordinator.getInstance();

        private List<CardPile> rootNodes = new();

        private RenderQueueUpdate renderQueueUpdate;
        private TestSystem testSystem;
        private UpdateSystem updateSystem;
        private RenderSystem renderSystem = new();
        private ClickSystem clickSystem;

        public Application(int width, int height) { cache = new Bitmap(width, height); }

        public void Initialize()
        {
            coordinator.RegisterComponent<Root>();
            coordinator.RegisterComponent<Renderable>();
            coordinator.RegisterComponent<Parent>();
            coordinator.RegisterComponent<Interactable>();
            coordinator.RegisterComponent<CardProperties>();
            coordinator.RegisterComponent<Child>();
            coordinator.RegisterComponent<Selected>();
            coordinator.RegisterComponent<Update>();


            renderQueueUpdate = coordinator.RegisterSystem<RenderQueueUpdate>();
            clickSystem = coordinator.RegisterSystem<ClickSystem>();
            testSystem = coordinator.RegisterSystem<TestSystem>();
            updateSystem = coordinator.RegisterSystem<UpdateSystem>();

            //CreateNode((int)CardType.CLUBS, 4);
            CardPileA cardpile = new (new Point(200,50), CardPileA.Type.PILE), cardpile2 = new CardPileA(cardpile, new Point(50, 50));
            List<Point> cards = new();
            rootNodes.Add(cardpile2);
            rootNodes.Add(cardpile);
            for(int i = 0; i<4; i++)
            {
                for (int j = 0; j < 13; j++) {
                    cards.Add(new Point(i, j));
                }
            }
            Program.Shuffle(ref cards);
            
            
            for(int i = 0; i < 7; i++) rootNodes.Add(new CardPileB(new Point(60 + i*150, 300)));
            for (int i = 0; i < 4; i++) rootNodes.Add(new CardPileC(new Point(520 + i* 150, 50)));

            for(int i = (int)CardPiles.TABLEAU,k=0; i< (int)CardPiles.FOUNDATION; i++,k++)
            {
                for(int j = 0; j<k; j++) { Point a = Program.RemoveLastElement(ref cards); rootNodes[i].AddNode(CreateNode(a.X,a.Y,new Point())); }
            }

            foreach (var p in cards) cardpile2.AddNode(CreateNode(p.X,p.Y, new Point()));


            cacheGraphics = Graphics.FromImage(cache);
            cacheGraphics.Clear(Color.Black);
            cacheGraphics.DrawImage(ImageUtils.getInstance().getBackground(), 0, 0);
            renderQueueUpdate.Update(ref renderSystem.renderQueue);
            renderSystem.Update(cacheGraphics);
        }

        private Entity CreateNode(int type, int num, Point pos, Entity parent = -1)
        {
            Entity node = coordinator.CreateEntity(num,type, pos);
            //coordinator.AddComponent(node, new Renderable(new Rectangle(num*109+19*num, 153*type+13*type, 109, 153), new Rectangle(100,100,109,153)));
            //coordinator.AddComponent(node, new CardProperties(num, type));

            var properties = coordinator.GetComponent<CardProperties>(node);
            var interactable = coordinator.GetComponent<Interactable>(node);
            var renderable = coordinator.GetComponent<Renderable>(node);
            interactable.onClick = new Interactable.Click(() => {
                if(!properties.isRevealed)
                {
                    if (coordinator.EntityHasComponent<Child>(node)) return;
                    renderable.ImageUV.X = properties.num * 109 + 19 * properties.num;
                    renderable.ImageUV.Y = (int)properties.cardType * 153 + (int)properties.cardType * 13;
                    properties.isRevealed = !properties.isRevealed;
                    coordinator.AddComponent(node, new Update { });
                }
            });
            interactable.onDrag = new Interactable.Drag(() => {
                if (!properties.isRevealed) return;
                coordinator.AddComponent(node, new Update { });
                renderable.UVRect.X -= Input.getInstance().getMouseDelta().X;
                renderable.UVRect.Y -= Input.getInstance().getMouseDelta().Y;
                coordinator.AddComponent(node, new Selected { });
                
                Entity child;
                if(coordinator.EntityHasComponent<Child>(node) && (child= coordinator.GetComponent<Child>(node).value) != 0)
                {
                    coordinator.GetComponent<Interactable>(child).onDrag();
                }
                //Console.WriteLine(renderable.UVRect);
                //Console.WriteLine(Input.getInstance().getMouseDelta());
            });
            interactable.onRelease = new Interactable.Release(() =>
            {
                coordinator.RemoveComponent<Selected>(node);
                coordinator.AddComponent(node, new Update { });
                Stack<int> stack = new Stack<int>();
                bool flag = false;
                foreach (var p in rootNodes)
                {
                    if (!Coordinator.getInstance().GetComponent<Root>(p.getId()).CheckBounds(renderable.UVRect) || p.getId() == Coordinator.getInstance().GetComponent<Parent>(node).value) continue;
                    Entity child = node;
                    if (!Coordinator.getInstance().GetComponent<Root>(p.getId()).Check(node)) continue;
                    flag = true;
                    stack.Push(node);
                    
                    while (coordinator.EntityHasComponent<Child>(child))
                    {
                        child = coordinator.GetComponent<Child>(child).value;
                        stack.Push(child);
                        coordinator.RemoveComponent<Selected>(child);
                        coordinator.AddComponent(child, new Update { });
                    }
                    ((CardPile)Coordinator.getInstance().GetEntity(Coordinator.getInstance().GetComponent<Parent>(node).value)).Transfer(ref stack, p);
                    break;

                }
                coordinator.GetEntity(node).ResetPosition();
                if(!flag)
                {
                    int a = node;
                    while(coordinator.EntityHasComponent<Child>(a))
                    {
                        a = coordinator.GetComponent<Child>(a).value;
                        coordinator.GetEntity(a).ResetPosition();
                    }
                }
                
            });
                //componentManager.AddComponent(node, Parent);
            return node;
        }

        public void run(Form1 form)
        {
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            HashSet<CardPile> parents = new();
            
            timer.Interval = 1;
            long currentTime = DateTimeOffset.Now.ToUnixTimeMilliseconds(), lastTime = DateTimeOffset.Now.ToUnixTimeMilliseconds();
            timer.Tick += (sender, e) => {
                currentTime = DateTimeOffset.Now.ToUnixTimeMilliseconds();

                if (currentTime - lastTime < 16) return;
                lastTime = currentTime;
                renderQueueUpdate.Update(ref renderSystem.renderQueue);
                testSystem.Update(ref renderSystem.renderQueue);
                updateSystem.Update(ref parents, );


                renderSystem.renderQueue.Clear();
                parents.Clear();

                form.Invalidate();
                Input.getInstance().setEventType(Input.EventType.NONE);


            };
            timer.Start();
            
        }

        public void handleInput(object sender, MouseEventArgs e)
        {
            clickSystem.Update();
        }

        public void render(object sender, PaintEventArgs e, int width, int height)
        {
            
            e.Graphics.DrawImageUnscaled(cache, 0, 0, width, height);
            //Console.WriteLine(Input.getInstance().getMousePos());
            //Console.WriteLine(Input.getInstance().getMouseDelta());

            
            
        }
    }
}
