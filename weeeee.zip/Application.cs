﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

using Entity = System.Int32;

namespace weeeee
{
    internal class Application
    {


        private ComponentManager componentManager = new ComponentManager();

        private List<Entity> nodes = new List<Entity>();

        public Application() { }

        public void Initialize()
        {
            componentManager.RegisterComponent<Parent>();
            componentManager.RegisterComponent<Child>();
            componentManager.RegisterComponent<Renderable>();
            componentManager.RegisterComponent<CardProperties>();

            nodes.Add(CreateNode((int)CardType.CLUBS, 4));
        }

        private Entity CreateNode(int type, int num, Entity parent = -1)
        {
            Entity node = componentManager.CreateEntity();
            componentManager.AddComponent(node, new Renderable(new Rectangle(num*109+19*num, 153*type+13*type, 109, 153), new Rectangle(100,100,109,153)));
            componentManager.AddComponent(node, new CardProperties(num, type));

            var properties = componentManager.GetComponent<CardProperties>(node);
            properties.onClick = new CardProperties.Click(() => { });
            properties.onDrag = new CardProperties.Drag(() => {
                componentManager.GetComponent<Renderable>(node).UVRect.X += Input.getInstance().getMouseDelta().X;
                componentManager.GetComponent<Renderable>(node).UVRect.Y += Input.getInstance().getMouseDelta().Y;
            });
            //componentManager.AddComponent(node, Parent);
            return node;
        }

        public void run()
        {
            
        }

        public void handleInput(object sender, MouseEventArgs e)
        {
            Input.getInstance().setMouseType(Input.MouseType.MOUSEDOWN);
            
        }

        public void render(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(ImageUtils.getInstance().getBackground(), 0, 0);
            Console.WriteLine(Input.getInstance().getMousePos());
            Console.WriteLine(Input.getInstance().getMouseDelta());
            foreach(var p in nodes)
            {
                componentManager.GetComponent<Renderable>(p).render(e.Graphics);
            }
        }
    }
}
