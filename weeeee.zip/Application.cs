﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

using Entity = System.Int32;

namespace weeeee
{
    internal class Application
    {

        private Coordinator coordinator = Coordinator.getInstance();

        private List<Node> rootNodes = new();

        private RenderSystem renderSystem;
        private ClickSystem clickSystem;

        public Application() { }

        public void Initialize()
        {
            coordinator.RegisterComponent<Root>();
            coordinator.RegisterComponent<Renderable>();
            coordinator.RegisterComponent<Parent>();
            coordinator.RegisterComponent<CardProperties>();
            coordinator.RegisterComponent<Child>();

            renderSystem = coordinator.RegisterSystem<RenderSystem>();
            clickSystem = coordinator.RegisterSystem<ClickSystem>();

            //CreateNode((int)CardType.CLUBS, 4);
            CardPileA cardpile = new (new Point(250,50), CardPileA.Type.PILE), cardpile2 = new CardPileA(cardpile, new Point(50, 50));
            rootNodes.Add(cardpile2);
            rootNodes.Add(cardpile);
            cardpile2.AddNode(CreateNode((int)CardType.CLUBS, 4, new Point()));
            
        }

        private Entity CreateNode(int type, int num, Point pos, Entity parent = -1)
        {
            Entity node = coordinator.CreateEntity(num,type, pos);
            //coordinator.AddComponent(node, new Renderable(new Rectangle(num*109+19*num, 153*type+13*type, 109, 153), new Rectangle(100,100,109,153)));
            //coordinator.AddComponent(node, new CardProperties(num, type));

            var properties = coordinator.GetComponent<CardProperties>(node);
            var renderable = coordinator.GetComponent<Renderable>(node);
            properties.onClick = new CardProperties.Click(() => {
                if(!properties.isRevealed)
                {
                    if (coordinator.GetComponent<Child>(node).value != 0) return;
                    renderable.ImageUV.X = properties.num * 109 + 19 * properties.num;
                    renderable.ImageUV.Y = (int)properties.cardType * 153 + (int)properties.cardType * 13;
                    properties.isRevealed = !properties.isRevealed;
                }
            });
            properties.onDrag = new CardProperties.Drag(() => {
                if (!properties.isRevealed) return;
                renderable.UVRect.X -= Input.getInstance().getMouseDelta().X;
                renderable.UVRect.Y -= Input.getInstance().getMouseDelta().Y;
                Entity child;
                if((child= coordinator.GetComponent<Child>(node).value) != 0)
                {
                    coordinator.GetComponent<CardProperties>(child).onDrag();
                }
                //Console.WriteLine(renderable.UVRect);
                //Console.WriteLine(Input.getInstance().getMouseDelta());
            });
            properties.onRelease = new CardProperties.Release(() => { });
            //componentManager.AddComponent(node, Parent);
            return node;
        }

        public void run(Form1 form)
        {
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 8;
            timer.Tick += (sender, e) => {
                form.Invalidate();
                Input.getInstance().setEventType(Input.EventType.NONE);
            };
            timer.Start();
        }

        public void handleInput(object sender, MouseEventArgs e)
        {
            clickSystem.Update();
        }

        public void render(object sender, PaintEventArgs e, int width, int height)
        {
            
            e.Graphics.DrawImage(ImageUtils.getInstance().getBackground(), 0, 0, width, height);
            //Console.WriteLine(Input.getInstance().getMousePos());
            //Console.WriteLine(Input.getInstance().getMouseDelta());
            renderSystem.Update(e.Graphics);
            
            
        }
    }
}
