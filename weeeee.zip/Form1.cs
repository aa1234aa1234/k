using System.Drawing.Drawing2D;
using System.Linq.Expressions;
using System.Reflection;

namespace weeeee
{
    public partial class Form1 : Form
    {
        Application app;
        Point lastClick;
        bool firstClick=true;

        public Form1()
        {
            InitializeComponent();
            //createcontrolregion(this, new Bitmap(@"C:\Users\sw_306\Desktop\fewa.png"));
            app = new Application();
            app.Initialize();
            this.MouseMove += (sender, e) => {
                Input.getInstance().setMousePos(e.Location);

                if (e.Button == MouseButtons.Left)
                {
                    Input.getInstance().setMouseDelta(new Point(lastClick.X - Input.getInstance().getMousePos().X, lastClick.Y - Input.getInstance().getMousePos().Y));
                    Input.getInstance().setEventType(Input.EventType.MOUSEDRAG);
                }
                else Input.getInstance().setEventType(Input.EventType.MOUSEMOVE);
                lastClick = e.Location;
                app.handleInput(sender, e);
            };
            this.MouseDown += (sender, e) => { 
                Input.getInstance().setEventType(Input.EventType.MOUSEDOWN);
                Input.getInstance().getMouseDown()[Input.MouseType.LEFT] = true;

                if (firstClick)
                {
                    lastClick = e.Location;
                    firstClick = false;
                }
                app.handleInput(sender, e); 
            };
            this.MouseUp += (sender, e) => { 
                Input.getInstance().setEventType(Input.EventType.MOUSEUP);
                Input.getInstance().getMouseDown()[Input.MouseType.LEFT] = false;
                app.handleInput(sender, e); 
            };
            this.Paint += (sender, e) => { app.render(sender, e, this.Width, this.Height);  };
            DoubleBuffered = true;

            app.run(this);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
           // imageList1.Images[0]
        }

        GraphicsPath calcgraphicspath(Bitmap bitmap)
        {
            GraphicsPath graphicspath = new GraphicsPath();
            Color colortransparent = bitmap.GetPixel(0, 0);
            int cop = 0;
            for(int row = 0; row<bitmap.Height; row++)
            {
                cop = 0;
                for(int col = 0; col < bitmap.Width; col++)
                {
                    if(bitmap.GetPixel(col,row) != colortransparent)
                    {
                        cop = col;
                        int colnext;
                        for(colnext = cop; colnext < bitmap.Width; colnext++)
                        {
                            if (bitmap.GetPixel(colnext, row) == colortransparent) break;
                        }
                        graphicspath.AddRectangle(new Rectangle(cop, row, colnext - cop, 1));
                        col = colnext;
                    }
                }
            }
            return graphicspath;
        }

        void createcontrolregion(Control control, Bitmap bitmap)
        {
            if (control == null || bitmap == null) return;
            control.Width = bitmap.Width; control.Height = bitmap.Height;
            if(control is System.Windows.Forms.Form)
            {
                Form form = (Form)control;
                form.Width += 20;
                form.Height += 80;
                form.FormBorderStyle = FormBorderStyle.None;
                form.BackgroundImage = bitmap;
                GraphicsPath graphicsPath = calcgraphicspath(bitmap);
                form.Region = new Region(graphicsPath);
            }
        }
    }
}
