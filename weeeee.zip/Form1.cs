using System.Drawing.Drawing2D;

namespace weeeee
{
    public partial class Form1 : Form
    {
        List<Node> nodes = new List<Node>();
        Application app;

        public Form1()
        {
            InitializeComponent();
            createcontrolregion(this, new Bitmap(@"C:\Users\sw_306\Desktop\fewa.png"));
            app = new Application();
            this.Paint += (sender, e) => { app.render(sender, e); };
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        GraphicsPath calcgraphicspath(Bitmap bitmap)
        {
            GraphicsPath graphicspath = new GraphicsPath();
            Color colortransparent = bitmap.GetPixel(0, 0);
            int cop = 0;
            for(int row = 0; row<bitmap.Height; row++)
            {
                cop = 0;
                for(int col = 0; col < bitmap.Width; col++)
                {
                    if(bitmap.GetPixel(col,row) != colortransparent)
                    {
                        cop = col;
                        int colnext;
                        for(colnext = cop; colnext < bitmap.Width; colnext++)
                        {
                            if (bitmap.GetPixel(colnext, row) == colortransparent) break;
                        }
                        graphicspath.AddRectangle(new Rectangle(cop, row, colnext - cop, 1));
                        col = colnext;
                    }
                }
            }
            return graphicspath;
        }

        void createcontrolregion(Control control, Bitmap bitmap)
        {
            if (control == null || bitmap == null) return;
            control.Width = bitmap.Width; control.Height = bitmap.Height;
            if(control is System.Windows.Forms.Form)
            {
                Form form = (Form)control;
                form.Width += 20;
                form.Height += 80;
                form.FormBorderStyle = FormBorderStyle.None;
                form.BackgroundImage = bitmap;
                GraphicsPath graphicsPath = calcgraphicspath(bitmap);
                form.Region = new Region(graphicsPath);
            }
        }
    }
}
