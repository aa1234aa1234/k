﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;
using System.Threading.Tasks;

using Entity = System.Int32;

namespace weeeee
{
    internal class App
    {
        Bitmap cache;
        Graphics cacheGraphics;

        enum CardPiles
        {
            DECK=0,
            TABLEAU=2,
            FOUNDATION=9
        }

        private Coordinator coordinator = Coordinator.getInstance();
        private System.Windows.Forms.Timer timer;

        private List<CardPile> rootNodes = new();

        private RenderQueueUpdate renderQueueUpdate;
        private TestSystem testSystem;
        private UpdateSystem updateSystem;
        private RenderSystem renderSystem = new();
        private ClickSystem clickSystem;

        public App(int width, int height) { cache = new Bitmap(width, height); }

        public void Initialize()
        {
            coordinator.RegisterComponent<Root>();
            coordinator.RegisterComponent<Renderable>();
            coordinator.RegisterComponent<Parent>();
            coordinator.RegisterComponent<Interactable>();
            coordinator.RegisterComponent<CardProperties>();
            coordinator.RegisterComponent<Child>();
            coordinator.RegisterComponent<Selected>();
            coordinator.RegisterComponent<Update>();
            coordinator.RegisterComponent<DisableChildDragging>();


            renderQueueUpdate = coordinator.RegisterSystem<RenderQueueUpdate>();
            clickSystem = coordinator.RegisterSystem<ClickSystem>();
            testSystem = coordinator.RegisterSystem<TestSystem>();
            updateSystem = coordinator.RegisterSystem<UpdateSystem>();

            //CreateNode((int)CardType.CLUBS, 4);
            CardPileA cardpile = new (new Point(200,50), CardPileA.Type.PILE), cardpile2 = new CardPileA(cardpile, new Point(50, 50));
            List<Point> cards = new();
            rootNodes.Add(cardpile2);
            rootNodes.Add(cardpile);
            for(int i = 0; i<4; i++)
            {
                for (int j = 0; j < 13; j++) {
                    cards.Add(new Point(i, j));
                }
            }
            Program.Shuffle(ref cards);
            
            
            for(int i = 0; i < 7; i++) rootNodes.Add(new CardPileB(new Point(60 + i*150, 300)));
            for (int i = 0; i < 4; i++) rootNodes.Add(new CardPileC(new Point(520 + i* 150, 50)));

            for(int i = (int)CardPiles.TABLEAU,k=0; i< (int)CardPiles.FOUNDATION; i++,k++)
            {
                for(int j = 0; j<k; j++) { Point a = Program.RemoveLastElement(ref cards); rootNodes[i].AddNode(CreateNode(a.X,a.Y,new Point())); }
            }

            foreach (var p in cards) cardpile2.AddNode(CreateNode(p.X,p.Y, new Point()));


            cacheGraphics = Graphics.FromImage(cache);
            cacheGraphics.Clear(Color.Black);
            cacheGraphics.DrawImage(ImageUtils.getInstance().getBackground(), 0, 0);
            renderQueueUpdate.Update(renderSystem.renderQueue);
            renderSystem.Update(cacheGraphics);
            renderSystem.renderQueue.Clear();
        }

        private void CheckValidSpot(Entity entity)
        {
            if (coordinator.EntityHasComponent<Child>(entity)) return;
            Stack<Entity> stack=new();
            for (int i = (int)CardPiles.FOUNDATION; i < (int)CardPiles.FOUNDATION + 4; i++)
            {
                if (rootNodes[i].GetRoot().Check(entity))
                {
                    stack.Push(entity);
                    ((CardPile)Coordinator.getInstance().GetEntity(Coordinator.getInstance().GetComponent<Parent>(entity).value)).Transfer(ref stack, rootNodes[i]);
                    coordinator.GetEntity(entity).ResetPosition();
                    int cnt = 0;
                    for (int j = (int)CardPiles.FOUNDATION; j < (int)CardPiles.FOUNDATION + 4; j++)
                    {
                        cnt += rootNodes[j].GetRoot().children.Count;
                    }
                    if (cnt == 52)
                    {
                        MessageBox.Show("You Win");

                        timer.Stop();
                    }
                    return;
                }
            }
        }

        private Entity CreateNode(int type, int num, Point pos, Entity parent = -1)
        {
            Entity node = coordinator.CreateEntity(num,type, pos);
            //coordinator.AddComponent(node, new Renderable(new Rectangle(num*109+19*num, 153*type+13*type, 109, 153), new Rectangle(100,100,109,153)));
            //coordinator.AddComponent(node, new CardProperties(num, type));

            var properties = coordinator.GetComponent<CardProperties>(node);
            var interactable = coordinator.GetComponent<Interactable>(node);
            var renderable = coordinator.GetComponent<Renderable>(node);
            interactable.onClick = new Interactable.Click(() => {
                if (!properties.isRevealed)
                {
                    if (coordinator.EntityHasComponent<Child>(node)) return;
                    renderable.x = properties.num;
                    renderable.y = (int)properties.cardType;
                    properties.isRevealed = !properties.isRevealed;
                    coordinator.AddComponent(node, new Update { });
                    //(coordinator.GetEntity(coordinator.GetComponent<Parent>(node).value) as CardPile).GetRoot().UpdateGraphics();
                }
                else
                {
                    coordinator.AddComponent(node, new Selected { });
                    //Entity child=node;
                    //while (coordinator.EntityHasComponent<Child>(child))
                    //{
                    //    child = coordinator.GetComponent<Child>(child).value;
                    //    coordinator.AddComponent(child, new Selected { });
                    //}
                }
            });
            interactable.onDrag = new Interactable.Drag(() => {
                if (!properties.isRevealed) return;
                coordinator.AddComponent(node, new Update { value = new Point(renderable.UVRect.X,renderable.UVRect.Y) });
                coordinator.GetComponent<CardProperties>(node).lastpos = new Point(renderable.UVRect.X, renderable.UVRect.Y);
                renderable.UVRect.X -= Input.getInstance().getMouseDelta().X;
                renderable.UVRect.Y -= Input.getInstance().getMouseDelta().Y;
                coordinator.AddComponent(node, new Selected { });
                
                Entity child;
                if(coordinator.EntityHasComponent<Child>(node) && (child= coordinator.GetComponent<Child>(node).value) != 0)
                {
                    coordinator.GetComponent<Interactable>(child).onDrag();
                }
                //Console.WriteLine(renderable.UVRect);
                //Console.WriteLine(Input.getInstance().getMouseDelta());
            });
            interactable.onRelease = new Interactable.Release(() =>
            {
                if(coordinator.EntityHasComponent<Selected>(node)) coordinator.RemoveComponent<Selected>(node);
                //coordinator.AddComponent(node, new Update { });
                Stack<int> stack = new Stack<int>();
                bool flag = false;
                Entity child = node;
                stack.Push(node);
                while (coordinator.EntityHasComponent<Child>(child))
                {
                    child = coordinator.GetComponent<Child>(child).value;
                    stack.Push(child);
                    coordinator.RemoveComponent<Selected>(child);
                }
                foreach (var p in rootNodes)
                {
                    if (!Coordinator.getInstance().GetComponent<Root>(p.getId()).CheckBounds(renderable.UVRect) || p.getId() == Coordinator.getInstance().GetComponent<Parent>(node).value) continue;

                    if (!Coordinator.getInstance().GetComponent<Root>(p.getId()).Check(node)) continue;
                    //CheckValidSpot(node);
                    flag = true;
                    
                    ((CardPile)Coordinator.getInstance().GetEntity(Coordinator.getInstance().GetComponent<Parent>(node).value)).Transfer(ref stack, p);
                    break;

                }
                coordinator.GetEntity(node).ResetPosition();
                if(!flag)
                {
                    int a = node;
                    while(coordinator.EntityHasComponent<Child>(a))
                    {
                        a = coordinator.GetComponent<Child>(a).value;
                        coordinator.GetEntity(a).ResetPosition();
                    }
                }

                int cnt = 0;
                for (int i = (int)CardPiles.FOUNDATION; i < (int)CardPiles.FOUNDATION + 4; i++)
                {
                    cnt += rootNodes[i].GetRoot().children.Count;
                }
                if (cnt == 52)
                {
                    MessageBox.Show("You Win");

                    timer.Stop();
                }
            });

            properties.checkValidSpot = new CardProperties.CheckValidSpot(() =>
            {
                CheckValidSpot(node);
            });
                //componentManager.AddComponent(node, Parent);
            return node;
        }

        public void run(Form1 form)
        {

            timer = new System.Windows.Forms.Timer();
            HashSet<CardPile> parents = new();
            HashSet<Point> update = new();
            CardPile par;
            Rectangle lastRect=Rectangle.Empty;


            timer.Interval = 16;
            long currentTime = DateTimeOffset.Now.ToUnixTimeMilliseconds(), lastTime = DateTimeOffset.Now.ToUnixTimeMilliseconds();
            timer.Tick += (sender, e) => {
                currentTime = DateTimeOffset.Now.ToUnixTimeMilliseconds();

                //if (currentTime - lastTime < 16) return;
                lastTime = currentTime;
                //renderQueueUpdate.Update(renderSystem.renderQueue);
                //testSystem.Update(renderSystem.renderQueue);
                if((par=updateSystem.Update(parents, update, rootNodes)) == null) return;


                ////foreach (var p in update) cacheGraphics.DrawImage(ImageUtils.getInstance().getBackground(), p.X, p.Y, new Rectangle(p.X, p.Y, 109, 153), GraphicsUnit.Pixel);
                ////foreach (var p in parents)
                ////{
                ////    cacheGraphics.DrawImage(ImageUtils.getInstance().getBackground(), p.GetRoot().bounds.X, p.GetRoot().bounds.Y, new Rectangle(p.GetRoot().bounds.X, p.GetRoot().bounds.Y, 109, 153), GraphicsUnit.Pixel);
                ////    coordinator.GetComponent<Renderable>(p.getId()).render(cacheGraphics);
                ////    foreach (var k in p.GetRoot().children)
                ////    {
                ////        coordinator.GetComponent<Renderable>(k).render(cacheGraphics);
                ////    }
                ////}

                //foreach (var p in parents)
                //{
                //    rect = Rectangle.Union(rect, p.GetRoot().bounds);
                //    //cacheGraphics.DrawImage(background, p.GetRoot().bounds.X, p.GetRoot().bounds.Y, new Rectangle(p.GetRoot().bounds.X, p.GetRoot().bounds.Y, 109, 153), GraphicsUnit.Pixel);
                //    //coordinator.GetComponent<Renderable>(p.getId()).render(cacheGraphics);
                //    //foreach (var k in p.GetRoot().children)
                //    //{
                //    //    coordinator.GetComponent<Renderable>(k).render(cacheGraphics);
                //    //}
                //    p.GetRoot().ReDraw(cacheGraphics);
                //}
                //foreach (var p in par.GetRoot().children) coordinator.GetComponent<Renderable>(p).render(cacheGraphics);

                //if (parents.Count != 0) form.Invalidate();

                //renderSystem.renderQueue.Clear();
                //update.Clear();
                //parents.Clear();

                if (parents.Count == 0) return;

                List<int> drag = new();
                cacheGraphics.Clear(Color.Black);
                cacheGraphics.DrawImage(ImageUtils.getInstance().getBackground(), 0, 0);
                foreach (var p in rootNodes)
                {
                    if(coordinator.EntityHasComponent<Renderable>(p.getId())) coordinator.GetComponent<Renderable>(p.getId()).render(cacheGraphics);
                    foreach (var k in p.GetRoot().children)
                    {
                        if (!coordinator.EntityHasComponent<Selected>(k)) coordinator.GetComponent<Renderable>(k).render(cacheGraphics);
                        else drag.Add(k);
                    }
                }
                Rectangle rect = drag.Count != 0 ? coordinator.GetComponent<Renderable>(drag[0]).UVRect : new Rectangle();
                //Console.WriteLine(testSystem.entities.Count);
                if (lastRect.IsEmpty && drag.Count != 0) lastRect = Program.MakeRectangle(coordinator.GetComponent<CardProperties>(drag[0]).pos, 109, 153);

                foreach (var p in drag)
                {
                    var renderable = coordinator.GetComponent<Renderable>(p);
                    var properties = coordinator.GetComponent<CardProperties>(p);
                    rect = Rectangle.Union(rect, renderable.UVRect);
                    renderable.render(cacheGraphics);
                }
                form.Invalidate(rect == Rectangle.Empty ? rect : Rectangle.Union(rect,lastRect));
                lastRect = rect;

                Input.getInstance().setEventType(Input.EventType.NONE);


            };
            timer.Start();
            
        }

        public void handleInput(object sender, MouseEventArgs e)
        {
            Form1 form = System.Windows.Forms.Application.OpenForms["Form1"] as Form1;
            Image background = ImageUtils.getInstance().getBackground();
            HashSet<CardPile> parents = new();
            HashSet<Point> update = new();
            Rectangle rect = new Rectangle();
            CardPile par;
            clickSystem.Update();
            //if ((par = updateSystem.Update(parents, update, rootNodes)) == null) return; 
            //if (parents.Count != 0) rect = parents.ElementAt(0).GetRoot().bounds;
            //foreach (var p in update) cacheGraphics.DrawImage(background, p.X, p.Y, new Rectangle(p.X, p.Y, 109, 153), GraphicsUnit.Pixel);

            //foreach (var p in parents)
            //{
            //    //rect = Rectangle.Union(rect, p.GetRoot().bounds);
            //    //cacheGraphics.DrawImage(background, p.GetRoot().bounds.X, p.GetRoot().bounds.Y, new Rectangle(p.GetRoot().bounds.X, p.GetRoot().bounds.Y, 109, 153), GraphicsUnit.Pixel);
            //    //coordinator.GetComponent<Renderable>(p.getId()).render(cacheGraphics);
            //    //foreach (var k in p.GetRoot().children)
            //    //{
            //    //    coordinator.GetComponent<Renderable>(k).render(cacheGraphics);
            //    //}
            //    p.GetRoot().ReDraw(cacheGraphics);
            //}
            //foreach (var p in par.GetRoot().children)
            //{
            //    coordinator.GetComponent<Renderable>(p).render(cacheGraphics);
            //}

            //if (parents.Count != 0)
            //{
            //    form.Invalidate();


            //}

            

        }

        public void render(object sender, PaintEventArgs e, int width, int height)
        {
            e.Graphics.DrawImageUnscaled(cache, 0, 0, width, height);
            //Console.WriteLine(Input.getInstance().getMousePos());
            //Console.WriteLine(Input.getInstance().getMouseDelta());

            
            
        }
    }
}
