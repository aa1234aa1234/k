﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    class CardPile : Node
    {
        public CardPile() : base() { }

        public Root GetRoot()
        {
            return Coordinator.getInstance().GetComponent<Root>(getId());
        }

        public sealed override void AddNode(Int32 entity)
        {
            if (GetRoot().children.Count != 0) Coordinator.getInstance().AddComponent(GetRoot().children.GetLastElement(), new Child { value = entity });
            else Coordinator.getInstance().AddComponent(getId(), new Child { value = entity });
            Coordinator.getInstance().GetComponent<Root>(getId()).AddToPile(entity);
            if (Coordinator.getInstance().EntityHasComponent<Parent>(entity)) Coordinator.getInstance().RemoveComponent<Parent>(entity);
            Coordinator.getInstance().AddComponent(entity, new Parent { value = getId() });
            GetRoot().UpdateSignature();
            //Console.WriteLine(GetRoot().bitset.bits);
        }

        public void Transfer(ref Stack<int> stack, CardPile dest)
        {
            while (stack.Count != 0)
            {
                int card = stack.Pop();
                int last = GetRoot().children.RemoveLastElement();
                RemoveNode(last);
                dest.AddNode(card);
            }
        }

        public void RemoveNode(Int32 entity)
        {
            if (GetRoot().children.Count == 0) Coordinator.getInstance().RemoveComponent<Child>(getId());
            else Coordinator.getInstance().RemoveComponent<Child>(GetRoot().children.GetLastElement());
            GetRoot().UpdateSignature();
            GetRoot().RemoveFromPile();
        }
    }

    class CardPileA : CardPile
    {
        public enum Type
        {
            DECK = 0,
            PILE
        }

        public CardPileA otherPile;
        private Type type;

        public CardPileA(Point pos, Type type) : base()
        {
            Coordinator.getInstance().AddComponent(getId(), new Interactable() { onClick = new Interactable.Click(() => { this.update(); }) });
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().GetComponent<Root>(getId()).SetGap(0);
            Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();
            Root.Update update = new Root.Update(() =>
            {
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
            this.type = type;
        }

        public CardPileA(CardPileA otherPile, Point pos) : base()
        {
            this.otherPile = otherPile;
            otherPile.otherPile = this;
            this.type = otherPile.GetType() == Type.DECK ? Type.PILE : Type.DECK;
            Coordinator.getInstance().AddComponent(getId(), new Interactable() { onClick = new Interactable.Click(() => { this.update(); }) });
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().GetComponent<Root>(getId()).SetGap(0);
            Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();

            Root.Update update = new Root.Update(() =>
            {
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
        }

        public void update()
        {
            if (type == Type.DECK)
            {
                //Console.WriteLine(GetRoot().children.Count);
                if (GetRoot().children.Count == 0)
                {
                    while (otherPile.GetRoot().children.Count != 0)
                    {
                        int entity = otherPile.GetRoot().children.RemoveLastElement();
                        if (otherPile.GetRoot().children.Count == 0) Coordinator.getInstance().RemoveComponent<Child>(otherPile.getId());
                        else Coordinator.getInstance().RemoveComponent<Child>(otherPile.GetRoot().children.GetLastElement());
                        var propertiesa = Coordinator.getInstance().GetComponent<CardProperties>(entity);
                        var renderablea = Coordinator.getInstance().GetComponent<Renderable>(entity);
                        renderablea.ImageUV.X = 1 * 109 + 19 * 1;
                        renderablea.ImageUV.Y = 4 * 153 + 4 * 13;
                        propertiesa.isRevealed = !propertiesa.isRevealed;
                        Coordinator.getInstance().AddComponent(entity, new Update { });
                        AddNode(entity);
                    }
                    Coordinator.getInstance().AddComponent(otherPile.getId(), new Update { });
                    return;
                }
                int card = Coordinator.getInstance().GetComponent<Root>(getId()).children.RemoveLastElement();
                if (GetRoot().children.Count == 0)
                {
                    Coordinator.getInstance().AddComponent(getId(), new Update { });
                    Coordinator.getInstance().RemoveComponent<Child>(getId());
                }
                else Coordinator.getInstance().RemoveComponent<Child>(GetRoot().children.GetLastElement());
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(card);
                var renderable = Coordinator.getInstance().GetComponent<Renderable>(card);
                renderable.ImageUV.X = properties.num * 109 + 19 * properties.num;
                renderable.ImageUV.Y = (int)properties.cardType * 153 + (int)properties.cardType * 13;
                properties.isRevealed = true;
                Coordinator.getInstance().AddComponent(card, new Update { });
                otherPile.AddNode(card);

            }
        }



        public void AddNode(Int32 entity)
        {
            base.AddNode(entity);

            var properties = Coordinator.getInstance().GetComponent<Interactable>(entity);
            properties.onClick = new Interactable.Click(() =>
            {

                update();
            });
        }


        public Type GetType() { return type; }
    }

    class CardPileB : CardPile
    {
        public CardPileB(Point pos)
        {
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153)));
            GetRoot().bitset = new(18);
            Root.Update update = new Root.Update(() =>
            {
                if (GetRoot().children.Count == 0)
                {
                    Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new(18);
                    return;
                }
                var lastChild = Coordinator.getInstance().GetComponent<Root>(getId()).children.GetLastElement();
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(lastChild);
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = (properties.color == 0 ? properties.colorBitset >> 1 : properties.colorBitset << 1) + (properties.numBitset >> 1);
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
        }
    }

    class CardPileC : CardPile
    {
        public CardPileC(Point pos)
        {
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153)));
            GetRoot().SetGap(0);
            GetRoot().bitset = new Bitset(4) { bits = 15 } + new Bitset(13) { bits = 1 };
            //Console.WriteLine(GetRoot().bitset.bits);
            Root.Update update = new Root.Update(() =>
            {
                if (GetRoot().children.Count == 0)
                {
                    GetRoot().bitset = new Bitset(4) { bits = 15 } + new Bitset(13) { bits = 1 };
                    return;
                }
                var lastChild = Coordinator.getInstance().GetComponent<Root>(getId()).children.GetLastElement();
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(lastChild);
                Bitset a = new(4);
                a[(int)properties.cardType] = true;
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = (a) + (properties.numBitset << 1);
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
        }
    }
}
