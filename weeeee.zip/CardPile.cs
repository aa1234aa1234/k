﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    class CardPile : Node
    {
        public CardPile() : base() { }

        public Root GetRoot()
        {
            return Coordinator.getInstance().GetComponent<Root>(getId());
        }

        public sealed override void AddNode(Int32 entity)
        {
            Coordinator.getInstance().RemoveComponent<DisableChildDragging>(entity);
            if (GetRoot().children.Count != 0) Coordinator.getInstance().AddComponent(GetRoot().children.GetLastElement(), new Child { value = entity });
            else Coordinator.getInstance().AddComponent(getId(), new Child { value = entity });
            Coordinator.getInstance().GetComponent<Root>(getId()).AddToPile(entity);
            if (Coordinator.getInstance().EntityHasComponent<Parent>(entity)) Coordinator.getInstance().RemoveComponent<Parent>(entity);
            Coordinator.getInstance().AddComponent(entity, new Parent { value = getId() });
            GetRoot().UpdateSignature();
            //Console.WriteLine(GetRoot().bitset.bits);
        }

        public override void Transfer(ref Stack<int> stack, CardPile dest)
        {
            List<int> a = new();
            while (stack.Count != 0)
            {
                int card = stack.Pop();
                int last = GetRoot().children.RemoveLastElement();
                RemoveNode(last);
                a.Add(card);
            }
            a.Reverse();
            foreach(int p in a) dest.AddNode(p);
        }

        public void RemoveNode(Int32 entity)
        {
            if (GetRoot().children.Count == 0) Coordinator.getInstance().RemoveComponent<Child>(getId());
            else Coordinator.getInstance().RemoveComponent<Child>(GetRoot().children.GetLastElement());
            GetRoot().UpdateSignature();
            GetRoot().RemoveFromPile();
        }
    }

    class CardPileA : CardPile
    {
        public enum Type
        {
            DECK = 0,
            PILE
        }

        public CardPileA otherPile;
        private Type type;

        public CardPileA(Point pos, Type type) : base()
        {
            Coordinator.getInstance().AddComponent(getId(), new Interactable() { onClick = new Interactable.Click(() => { this.update(); }) });
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153), 2, 4));
            Coordinator.getInstance().GetComponent<Root>(getId()).SetGap(0);
            Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();
            Root.Update update = new Root.Update(() =>
            {
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
            this.type = type;
        }

        public CardPileA(CardPileA otherPile, Point pos) : base()
        {
            this.otherPile = otherPile;
            otherPile.otherPile = this;
            this.type = otherPile.GetType() == Type.DECK ? Type.PILE : Type.DECK;
            Coordinator.getInstance().AddComponent(getId(), new Interactable() { onClick = new Interactable.Click(() => { this.update(); }) });
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153), 2, 4));
            Coordinator.getInstance().GetComponent<Root>(getId()).SetGap(0);
            Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();

            Root.Update update = new Root.Update(() =>
            {
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
        }

        public void update()
        {
            if (type == Type.DECK)
            {
                //Console.WriteLine(GetRoot().children.Count);
                if (GetRoot().children.Count == 0)
                {
                    while (otherPile.GetRoot().children.Count != 0)
                    {
                        int entity = otherPile.GetRoot().children.RemoveLastElement();
                        if (otherPile.GetRoot().children.Count == 0) Coordinator.getInstance().RemoveComponent<Child>(otherPile.getId());
                        else Coordinator.getInstance().RemoveComponent<Child>(otherPile.GetRoot().children.GetLastElement());
                        var propertiesa = Coordinator.getInstance().GetComponent<CardProperties>(entity);
                        var renderablea = Coordinator.getInstance().GetComponent<Renderable>(entity);
                        renderablea.x = 1;
                        renderablea.y = 4;
                        propertiesa.isRevealed = !propertiesa.isRevealed;
                        Coordinator.getInstance().AddComponent(entity, new Update { });
                        AddNode(entity);
                    }
                    Coordinator.getInstance().AddComponent(otherPile.getId(), new Update { });
                    return;
                }
                int card = Coordinator.getInstance().GetComponent<Root>(getId()).children.RemoveLastElement();
                if (GetRoot().children.Count == 0)
                {
                    Coordinator.getInstance().AddComponent(getId(), new Update { });
                    Coordinator.getInstance().RemoveComponent<Child>(getId());
                }
                else
                {
                    Coordinator.getInstance().RemoveComponent<Child>(GetRoot().children.GetLastElement());
                }
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(card);
                var renderable = Coordinator.getInstance().GetComponent<Renderable>(card);
                renderable.x = properties.num;
                renderable.y = (int)properties.cardType;
                properties.isRevealed = true;
                Coordinator.getInstance().AddComponent(card, new Update { });
                otherPile.AddNode(card);
                
            }
        }


        public override void Transfer(ref Stack<int> stack, CardPile dest)
        {
            base.Transfer(ref stack, dest);
            var children = GetRoot().children;
            if (type == Type.PILE)
            {
                if(children.Count >= 3)
                {
                    for(int i = children.Count - 2; i <= children.Count - 1; i++)
                    {
                        if (i < 0 || i >= children.Count) continue;
                        var p = Coordinator.getInstance().GetComponent<CardProperties>(children[i]);
                        Coordinator.getInstance().GetEntity(children[i]).UpdatePosition(new Point(p.pos.X + 40, p.pos.Y));
                    }
                }
            }
        }

        public void AddNode(Int32 entity)
        {
            if (type == Type.PILE)
            {
                
                var children = GetRoot().children;
                if (children.Count >= 3)
                    for (int i = children.Count - 2,k=0; k<2; k++,i++)
                    {
                        if (i < 0 || i >= children.Count) break;
                        var p = Coordinator.getInstance().GetComponent<CardProperties>(children[i]);
                        p.pos.X -= 40;
                        //Console.WriteLine(i + k + " " + p.pos.X);
                        Coordinator.getInstance().GetEntity(children[i]).UpdatePosition(p.pos);
                    }
            }
            base.AddNode(entity);
            //Coordinator.getInstance().GetComponent<Root>(getId()).AddToPile(entity);
            //if (Coordinator.getInstance().EntityHasComponent<Parent>(entity)) Coordinator.getInstance().RemoveComponent<Parent>(entity);
            //Coordinator.getInstance().AddComponent(entity, new Parent { value = getId() });
            //GetRoot().UpdateSignature();

            var properties = Coordinator.getInstance().GetComponent<Interactable>(entity);
            properties.onClick = new Interactable.Click(() =>
            {

                if (type == Type.DECK && otherPile.GetRoot().children.Count == 0) for (int i = 0; i < (GetRoot().children.Count >= 3 ? 3 : GetRoot().children.Count); i++) update();
                else update();
            });
            if(type == Type.PILE)
            {
                Coordinator.getInstance().AddComponent(entity, new DisableChildDragging { });
                var children = GetRoot().children;
                if(children.Count > 1)
                {
                    var p = Coordinator.getInstance().GetComponent<CardProperties>(children[children.Count - 2]);
                    Coordinator.getInstance().GetEntity(entity).UpdatePosition(new Point(p.pos.X+40, p.pos.Y));
                }
                
            }
            
        }


        public Type GetType() { return type; }
    }

    class CardPileB : CardPile
    {
        public CardPileB(Point pos)
        {
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153), 2, 4));
            GetRoot().bitset = new(18);
            Root.Update update = new Root.Update(() =>
            {
                if (GetRoot().children.Count == 0)
                {
                    Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new(18);
                    return;
                }
                var lastChild = Coordinator.getInstance().GetComponent<Root>(getId()).children.GetLastElement();
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(lastChild);
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = (properties.color == 0 ? new Bitset(4) { bits=5} : new Bitset(4) { bits = 10 }) + (properties.numBitset >> 1);
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
        }
    }

    class CardPileC : CardPile
    {
        public CardPileC(Point pos)
        {
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153), 2, 4));
            GetRoot().SetGap(0);
            GetRoot().bitset = new Bitset(4) { bits = 15 } + new Bitset(13) { bits = 1 };
            //Console.WriteLine(GetRoot().bitset.bits);
            Root.Update update = new Root.Update(() =>
            {
                if (GetRoot().children.Count == 0)
                {
                    GetRoot().bitset = new Bitset(4) { bits = 15 } + new Bitset(13) { bits = 1 };
                    return;
                }
                var lastChild = Coordinator.getInstance().GetComponent<Root>(getId()).children.GetLastElement();
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(lastChild);
                Bitset a = new(4);
                a[(int)properties.cardType] = true;
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = (a) + (properties.numBitset << 1);
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
        }
    }
}
