﻿namespace weeeee
{
    using System.DirectoryServices;
    using System.Security.Cryptography.Pkcs;
    using Entity = System.Int32;

    enum CardType
    {
        CLUBS=0,
        DIAMONDS,
        SPADES,
        HEARTS,
        JOKER,
    }

    struct Parent
    {
        public Entity Value;
    }

    struct Child
    {
        public Entity Value;
    }

    class Renderable
    {
        public Rectangle ImageUV,UVRect;
        public Renderable(Rectangle imageUV, Rectangle uVRect)
        {
            ImageUV = imageUV;
            UVRect = uVRect;
        }

        public void render(Graphics g)
        {
            g.DrawImage(ImageUtils.getInstance().getAtlas(), UVRect.X, UVRect.Y, ImageUV, GraphicsUnit.Pixel);
        }
    }

    class CardProperties
    {
        public bool isRevealed = false;
        public int num;
        public CardType cardType;
        public Click onClick;
        public Drag onDrag;
        public Release onRelease;

        public CardProperties(int num, int cardType)
        {
            this.num = num;
            this.cardType = (CardType)cardType;
        }

        public delegate void Click();
        public delegate void Drag();
        public delegate void Release();
    }
}