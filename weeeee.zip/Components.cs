﻿namespace weeeee
{
    using Microsoft.Win32.SafeHandles;
    using System.Collections.Specialized;
    using System.DirectoryServices;
    using System.Security.Cryptography.Pkcs;
    using Entity = System.Int32;

    enum CardType
    {
        CLUBS=0,
        DIAMONDS,
        SPADES,
        HEARTS,
        JOKER,
    }

    class Root
    {
        public List<Entity> children= new List<Entity>();
        public Bitset bitset = new Bitset();
        public Update UpdateSignature;
        public Rectangle bounds = new Rectangle();
        private int gap = 10, appendGap;

        public Root(Rectangle bounds) { this.bounds = bounds; }

        public void AddToPile(Entity entity)
        {
            appendGap = gap * ((Coordinator.getInstance().GetComponent<CardProperties>(entity).isRevealed == true) ? 2 : 1);
            int a = children.Count != 0 ? Coordinator.getInstance().GetComponent<CardProperties>(children.GetLastElement()).pos.Y + appendGap : bounds.Y;
            
            Coordinator.getInstance().GetEntity(entity).UpdatePosition(new Point(bounds.X,a));
            //Console.WriteLine(bounds.Y + "fewafjwaeklf");
            children.Add(entity);
            
            
            bounds.Height += appendGap;
            
        }

        public bool Check(Entity entity)
        {
            //if (bitset.bits == Math.Pow(2, bitset.Length)) return true;
            if (children.Count != 0 && !Coordinator.getInstance().GetComponent<CardProperties>(children.GetLastElement()).isRevealed) return false;
            Bitset a = Coordinator.getInstance().GetComponent<CardProperties>(entity).GetBitset();
            return ((bitset & a) == bitset || (bitset & a) == a);
        }

        public bool CheckBounds(Rectangle bounds)
        {
            return this.bounds.IntersectsWith(bounds);
        }

        public void SetGap(int g) { gap = g; }

        public delegate void Update();
    }

    struct Parent
    {
        public Entity value;
    }

    struct Child
    {
        public Entity value;
    }

    struct Selected { }

    struct Update { }

    class Interactable
    {
        public Click onClick;
        public Drag onDrag;
        public Release onRelease;

        public delegate void Click();
        public delegate void Drag();
        public delegate void Release();
    }

    class Renderable
    {
        public Rectangle ImageUV,UVRect;
        public Renderable(Rectangle imageUV, Rectangle uVRect)
        {
            ImageUV = imageUV;
            UVRect = uVRect;
        }

        public void render(Graphics g)
        {
            g.DrawImage(ImageUtils.getInstance().getAtlas(), UVRect.X, UVRect.Y, ImageUV, GraphicsUnit.Pixel);
        }
    }
}