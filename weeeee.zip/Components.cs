﻿namespace weeeee
{
    using Microsoft.Win32.SafeHandles;
    using System.Collections.Specialized;
    using System.DirectoryServices;
    using System.Security.Cryptography.Pkcs;
    using Entity = System.Int32;

    enum CardType
    {
        CLUBS=0,
        DIAMONDS,
        SPADES,
        HEARTS,
        JOKER,
    }

    class Root
    {
        public List<Entity> children= new List<Entity>();
        public Bitset bitset = new Bitset();
        public Update UpdateSignature;
        public Rectangle bounds = new Rectangle();
        private int gap = 10;

        public void AddToPile(Entity entity)
        {
            children.Add(entity);
            //Coordinator.getInstance().GetEntity(entity).UpdatePosition(new Point())
        }

        public bool Check(Entity entity)
        {
            return ((bitset & Coordinator.getInstance().GetComponent<CardProperties>(entity).bitset) == bitset ? true : false);
        }

        public delegate void Update();
    }

    struct Parent
    {
        public Entity value;
    }

    struct Child
    {
        public Entity value;
    }

    class Renderable
    {
        public Rectangle ImageUV,UVRect;
        public Renderable(Rectangle imageUV, Rectangle uVRect)
        {
            ImageUV = imageUV;
            UVRect = uVRect;
        }

        public void render(Graphics g)
        {
            g.DrawImage(ImageUtils.getInstance().getAtlas(), UVRect.X, UVRect.Y, ImageUV, GraphicsUnit.Pixel);
        }
    }
}