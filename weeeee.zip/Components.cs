﻿namespace weeeee
{
    using System.Security.Cryptography.Pkcs;
    using Entity = System.Int32;

    enum CardType
    {
        SPADES=0,
        DIAMONDS,
        CLUBS,
        HEARTS
    }

    struct Parent
    {
        public Entity Value;
    }

    struct Child
    {
        public Entity Value;
    }

    struct Renderable
    {
        public Rectangle ImageUV,UV;
    }

    class Properties
    {
        public bool isRevealed = false;
        public int num;
        public CardType cardType;
    }
}