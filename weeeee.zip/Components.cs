﻿namespace weeeee
{
    using Microsoft.Win32.SafeHandles;
    using System.Collections.Specialized;
    using System.DirectoryServices;
    using System.Security.Cryptography.Pkcs;
    using Entity = System.Int32;

    enum CardType
    {
        CLUBS=0,
        DIAMONDS,
        SPADES,
        HEARTS,
        JOKER,
    }

    class Root
    {
        public List<Entity> children= new List<Entity>();
        public Bitset bitset = new Bitset();
        private Graphics bitmapGraphics;
        public Bitmap bitmap;
        public Update UpdateSignature;
        public Rectangle bounds = new Rectangle();
        private int gap = 10, appendGap;

        public Root(Rectangle bounds) { 
            this.bounds = bounds; 
            bitmap = new(bounds.Width, bounds.Height);
            bitmapGraphics = Graphics.FromImage(bitmap);
            UpdateGraphics();
        }

        public void AddToPile(Entity entity)
        {
            appendGap = gap * ((Coordinator.getInstance().GetComponent<CardProperties>(entity).isRevealed == true) ? 2 : 1);
            int a = children.Count != 0 ? Coordinator.getInstance().GetComponent<CardProperties>(children.GetLastElement()).pos.Y + appendGap : bounds.Y;
            
            Coordinator.getInstance().GetEntity(entity).UpdatePosition(new Point(bounds.X,a));
            //Console.WriteLine(bounds.Y + "fewafjwaeklf");
            children.Add(entity);
            
            
            bounds.Height += appendGap;
            bitmap = new Bitmap(bitmap, new Size(bounds.Width, bounds.Height));
            bitmapGraphics.Dispose();
            bitmapGraphics = Graphics.FromImage(bitmap);
            UpdateGraphics();

        }

        public void RemoveFromPile()
        {
            bounds.Height -= appendGap;
            bitmap = new Bitmap(bitmap, new Size(bounds.Width, bounds.Height));
            bitmapGraphics.Dispose();
            bitmapGraphics = Graphics.FromImage(bitmap);
            UpdateGraphics();
        }

        public bool Check(Entity entity)
        {
            //if (bitset.bits == Math.Pow(2, bitset.Length)) return true;
            if (children.Count != 0 && !Coordinator.getInstance().GetComponent<CardProperties>(children.GetLastElement()).isRevealed) return false;
            Bitset a = Coordinator.getInstance().GetComponent<CardProperties>(entity).GetBitset();
            return ((bitset & a) == bitset || (bitset & a) == a);
        }

        public bool CheckBounds(Rectangle bounds)
        {
            return this.bounds.IntersectsWith(bounds);
        }

        public void SetGap(int g) { gap = g; }

        public void ReDraw(Graphics graphics)
        {
            //graphics.DrawImage(ImageUtils.getInstance().getBackground(), bounds.X, bounds.Y, bounds, GraphicsUnit.Pixel);
            graphics.DrawImageUnscaled(bitmap, bounds.X, bounds.Y);
        }

        public void UpdateGraphics()
        {
            bitmapGraphics.Clear(Color.Transparent);
            bitmapGraphics.DrawImage(ImageUtils.getInstance().getAtlas(), 0, 0, new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), GraphicsUnit.Pixel);
            if (children.Count != 0)
            {
                int offset = Coordinator.getInstance().GetComponent<Renderable>(children[0]).UVRect.Y;
                foreach (var p in children)
                {
                    var renderable = Coordinator.getInstance().GetComponent<Renderable>(p);
                    renderable.render(bitmapGraphics, 0, renderable.UVRect.Y - offset);
                }
            }
        }

        public delegate void Update();
    }

    struct Parent
    {
        public Entity value;
    }

    struct Child
    {
        public Entity value;
    }

    struct Selected { }

    struct Update { public Point value; }

    class Interactable
    {
        public Click onClick;
        public Drag onDrag;
        public Release onRelease;

        public delegate void Click();
        public delegate void Drag();
        public delegate void Release();
    }

    class Renderable
    {
        public Rectangle ImageUV,UVRect;
        public Renderable(Rectangle imageUV, Rectangle uVRect)
        {
            ImageUV = imageUV;
            UVRect = uVRect;
        }

        public void render(Graphics g, int x = -1, int y = -1)
        {
            g.DrawImage(ImageUtils.getInstance().getAtlas(), x == -1 ? UVRect.X : x, y == -1 ? UVRect.Y : y, ImageUV, GraphicsUnit.Pixel);
        }
    }
}