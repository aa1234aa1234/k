﻿namespace weeeee
{
    using System.Collections.Specialized;
    using System.DirectoryServices;
    using System.Security.Cryptography.Pkcs;
    using Entity = System.Int32;

    enum CardType
    {
        CLUBS=0,
        DIAMONDS,
        SPADES,
        HEARTS,
        JOKER,
    }

    class Bitset
    {
        public ulong bits = 0 | (1u << 18);

        public bool this[int idx]
        {
            get => (bits & (1u << idx)) != 0;
            set
            {
                if (bits != 0) bits |= 1u << idx;
                else bits &= ~(1u << idx);
            }
        }

        public static Bitset operator &(Bitset a, Bitset b) => new() { bits = a.bits & b.bits };
    }

    class Root
    {
        public List<Entity> children= new List<Entity>(12);
        public Bitset bitset = new Bitset();
        public Update UpdateBitSet;

        public void AddToPile(Entity entity)
        {
            children.Add(entity);
        }

        public bool Check(Entity entity)
        {
            return ((bitset & Coordinator.getInstance().GetComponent<CardProperties>(entity).bitset).bits == 1 ? true : false);
        }

        public delegate void Update();
    }

    struct Parent
    {
        public Entity value;
    }

    class Renderable
    {
        public Rectangle ImageUV,UVRect;
        public Renderable(Rectangle imageUV, Rectangle uVRect)
        {
            ImageUV = imageUV;
            UVRect = uVRect;
        }

        public void render(Graphics g)
        {
            g.DrawImage(ImageUtils.getInstance().getAtlas(), UVRect.X, UVRect.Y, ImageUV, GraphicsUnit.Pixel);
        }
    }

    class CardProperties
    {
        public bool isRevealed = false;
        public int num;
        public int color;
        public CardType cardType;
        public Click onClick;
        public Drag onDrag;
        public Release onRelease;
        public Bitset bitset = new Bitset();

        public CardProperties(int num, int cardType)
        {
            this.num = num;
            this.cardType = (CardType)cardType;
            color = (cardType + 1) % 2;
        }

        public delegate void Click();
        public delegate void Drag();
        public delegate void Release();
    }
}