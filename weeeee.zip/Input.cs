﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class Input
    {
        public enum MouseType
        {
            MOUSEDOWN,
            MOUSEUP,
            NONE
        };
        public static Input instance;

        private Point mousePos, mouseDelta;

        private MouseType mouseType=MouseType.NONE;

        ~Input() { instance = null; }

        public static Input getInstance()
        {
            if(instance == null) instance =new Input(); return instance;
        }

        public Point getMousePos() { return mousePos; }
        public Point getMouseDelta() { return mouseDelta; }
        public MouseType getMouseType() { return mouseType; }
        public void setMouseType(MouseType mouseType) { this.mouseType = mouseType; }
        public void setMousePos(Point pos) { mousePos = pos; }
        public void setMouseDelta(Point delta) { mouseDelta = delta; }
    }
}
