﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class Input
    {
        public enum EventType
        {
            MOUSEDOWN,
            MOUSEUP,
            MOUSEMOVE,
            MOUSEDRAG,
            NONE
        };

        public enum MouseType
        {
            LEFT,
            RIGHT,
            MIDDLE
        }
        public static Input instance;

        private Point mousePos, mouseDelta;

        private EventType eventType = EventType.NONE;
        private Dictionary<MouseType, bool> mouseDown = new Dictionary<MouseType, bool>();

        Input()
        {
            mouseDown.Add(MouseType.LEFT,false);
            mouseDown.Add(MouseType.RIGHT, false);
            mouseDown.Add(MouseType.MIDDLE, false);
        }

        ~Input() { instance = null; }

        public static Input getInstance()
        {
            if(instance == null) instance =new Input(); return instance;
        }

        public Point getMousePos() { return mousePos; }
        public Point getMouseDelta() { return mouseDelta; }
        public EventType getEventType() { return eventType; }
        public void setEventType(EventType eventType) { this.eventType = eventType; }
        public Dictionary<MouseType, bool> getMouseDown() { return mouseDown; }
        public void setMousePos(Point pos) { mousePos = pos; }
        public void setMouseDelta(Point delta) { mouseDelta = delta; }
    }
}
