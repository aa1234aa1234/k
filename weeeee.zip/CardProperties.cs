﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    class CardProperties
    {
        public bool isRevealed = false;
        public int num;
        public int color;
        public CardType cardType;
        public Bitset colorBitset = new Bitset(4), numBitset = new(13);
        public Point pos;

        public CardProperties() { }

        public CardProperties(int num, int cardType, Point position)
        {
            this.num = num;
            this.cardType = (CardType)cardType;
            color = (cardType + 1) % 2;
            pos = position;
            if (color == 0) { colorBitset.bits = 10; }
            else { colorBitset.bits = 5; }
            numBitset[num] = true;
        }

        public Bitset GetBitset() { return colorBitset + numBitset; }

       

    }
}
