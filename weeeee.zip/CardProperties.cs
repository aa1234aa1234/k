﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    class CardProperties
    {
        public bool isRevealed = false;
        public int num;
        public int color;
        public CardType cardType;
        public Click onClick;
        public Drag onDrag;
        public Release onRelease;
        public Bitset colorBitset = new Bitset(), numBitset = new();
        public Point pos;

        public CardProperties() { }

        public CardProperties(int num, int cardType, Point position)
        {
            this.num = num;
            this.cardType = (CardType)cardType;
            color = (cardType + 1) % 2;
            pos = position;
        }

        public Bitset GetBitset() { return colorBitset + numBitset; }

        public delegate void Click();
        public delegate void Drag();
        public delegate void Release();

    }
}
