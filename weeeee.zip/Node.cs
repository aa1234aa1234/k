﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace weeeee
{
    internal class Node
    {
        Int32 nodeID = -1;
        static Int32 id = 0;

        public Node()
        {
            nodeID = id++;
        }

        public Node(int num, int type)
        {
            nodeID = id++;
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(1 * 109 + 19 * 1, 153 * 4 + 13 * 4, 109, 153), new Rectangle(100, 100, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new CardProperties(num, type, new Point(100,100)));
        }
        ~Node() { }

        public Int32 getId() { return nodeID; }

        public void update()
        {

        }

        public void revealCard() { }
        public void UpdatePosition(Point point)
        {
            var properties = Coordinator.getInstance().GetComponent<CardProperties>(getId());
            var renderable = Coordinator.getInstance().GetComponent<Renderable>(getId());
            properties.pos = point;
            renderable.UVRect.X = point.X;
            renderable.UVRect.Y = point.Y;
        }
    }

    class CardPileA : Node
    {
        private CardPileA otherPile;

        public CardPileA(CardPileA otherPile)
        {
            this.otherPile = otherPile;
        }

        public void update()
        {

        }

        public void revealCard() { }
    }

    interface IComponentArray {
        public void Remove(Int32 id);
    }
    
    class ComponentArray<T> : IComponentArray {
        private int componentCount = 0;
        private Dictionary<int, T> components;
        private Dictionary<int, int> IdToIdx,IdxToId;

        public ComponentArray() {
            components = new Dictionary<int, T>();
            IdToIdx = new Dictionary<int, int>();
            IdxToId = new Dictionary<int, int>();
        }

        public void AddComponent(Int32 id, T component)
        {
            if (component == null) throw new Exception("component is null");
            components[componentCount] = component;
            IdxToId[componentCount] = id;
            IdToIdx[id] = componentCount;
            componentCount++;
        }

        public T Get(Int32 id)
        {
            return components[IdToIdx[id]];
        }

        public void Remove(Int32 id)
        {
            int idx = IdToIdx[id];
            int last = components.Count - 1;

            components[idx] = components[last];
            int a = IdxToId[last];

            IdToIdx[a] = idx;
            IdxToId[idx] = a;

            components.Remove(last);
            IdToIdx.Remove(id);
            IdxToId.Remove(last);
        }
    }

    class ComponentManager
    {
        Dictionary<string, IComponentArray> componentArrays;
        Dictionary<Type, int> componentTypes;
        int componentType = 0;

        public ComponentManager() { 
            componentArrays = new Dictionary<string, IComponentArray>();
            componentTypes = new Dictionary<Type, int>();
        }

        private ComponentArray<T> GetComponentArray<T>()
        {
            if (componentArrays[typeof(T).Name] == null) return null;
            return (ComponentArray<T>)componentArrays[typeof(T).Name];
        }

        public void RegisterComponent<T>()
        {
            componentArrays.Add(typeof(T).Name, new ComponentArray<T>());
            componentTypes.Add(typeof(T), componentType);
            ++componentType;
        }

        public int GetComponentType<T>()
        {
            return componentTypes[typeof(T)];
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            GetComponentArray<T>().AddComponent(id, component);
        }

        public T GetComponent<T>(Int32 id)
        {
            return GetComponentArray<T>().Get(id);
        }

        public Int32 CreateEntity()
        {
            return new Node().getId();
        } 
    }
    class EntityManager
    {
        private List<Node> entities = new List<Node>();
        private List<Bitset> signatures = new List<Bitset>();

        public void AddEntity(Node node)
        {
            Node[] nodes = entities.ToArray();
            Array.Resize(ref nodes, node.getId() + 1);
            nodes[node.getId()] = node;
            entities = nodes.ToList();

        }

        public Node GetEntity(Int32 id)
        {
            return entities[id];
        }

        public List<Node> GetEntities() { return entities; }

        public void SetSignature(Int32 entity, Bitset signature)
        {
            signatures[entity] = signature;
        }

        public Bitset GetSignature(Int32 entity)
        {
            if (entity >= signatures.Count) for (int i = 0; i <= entity; i++) signatures.Add(new Bitset());
            return signatures[entity];
        }
    }

    class Coordinator
    {
        private EntityManager entityManager = new EntityManager();
        private ComponentManager componentManager = new ComponentManager();
        private SystemManager systemManager = new SystemManager();

        private static Coordinator instance;

        ~Coordinator()
        {
            instance = null;
        }

        public static Coordinator getInstance()
        {
            if(instance == null) instance = new Coordinator();
            return instance;
        }

        public void RegisterComponent<T>()
        {
            componentManager.RegisterComponent<T>();
        }

        public int GetComponentType<T>()
        {
            return componentManager.GetComponentType<T>();
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            componentManager.AddComponent(id, component);
            Bitset bitset = entityManager.GetSignature(id);
            bitset[componentManager.GetComponentType<T>()] = true;
            entityManager.SetSignature(id, bitset);
            systemManager.UpdateEntitySystem(id, bitset);
        }

        public T GetComponent<T>(Int32 id)
        {
            return componentManager.GetComponent<T>(id);
        }

        public Int32 CreateEntity()
        {
            Node node = new Node();
            entityManager.AddEntity(node);
            return node.getId();
        }

        public Int32 CreateEntity(int num, int type)
        {
            Node node = new Node(num, type);
            entityManager.AddEntity(node);
            return node.getId();
        }

        public Node GetEntity(Int32 id)
        {
            return entityManager.GetEntity(id);
        }

        public List<Node> GetEntities() { return entityManager.GetEntities(); }

        public T RegisterSystem<T>() where T : SignatureSystem, new()
        {
            return systemManager.RegisterSystem<T>();
        }

        public void SetSystemSignature<T>(Bitset signature)
        {
            systemManager.SetSystemSignature<T>(signature);
        }
    }

    class SignatureSystem
    {
        public HashSet<Int32> entities;

        public SignatureSystem() { entities = new HashSet<Int32>(); }
    }

    class SystemManager
    {
        private Dictionary<Type, SignatureSystem> systems;
        private Dictionary<Type, Bitset> signatures;

        public SystemManager()
        {
            systems = new Dictionary<Type, SignatureSystem>();
            signatures = new Dictionary<Type, Bitset>();
        }

        public T RegisterSystem<T>() where T : SignatureSystem, new()
        {
            T system = new T();
            systems[typeof(T)] = system;
            return system;
        }

        public void UpdateEntitySystem(Int32 entityID, Bitset updatedSignature)
        {
            foreach(KeyValuePair<Type, SignatureSystem> p in systems)
            {
                if ((updatedSignature & signatures[p.Key]) == signatures[p.Key])
                {
                    p.Value.entities.Add(entityID);
                    Console.WriteLine("hello");
                }
                else p.Value.entities.Remove(entityID);
            }
        }

        public void SetSystemSignature<T>(Bitset signature)
        {
            signatures[typeof(T)] = signature;
        }
    }
}


