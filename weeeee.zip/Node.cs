﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class Node
    {
        Int32 nodeID = -1;
        static Int32 id = 0;
        public Node()
        {
            nodeID = id++;
        }
        ~Node() { }

        public Int32 getId() { return nodeID; }
    }

    interface IComponentArray {
        public void Remove(Int32 id);
    }
    
    class ComponentArray<T> : IComponentArray {
        private int componentCount = 0;
        private Dictionary<int, T> components;
        private Dictionary<int, int> IdToIdx,IdxToId;

        public ComponentArray() {
            components = new Dictionary<int, T>();
            IdToIdx = new Dictionary<int, int>();
            IdxToId = new Dictionary<int, int>();
        }

        public void AddComponent(Int32 id, T component)
        {
            if (component == null) throw new Exception("component is null");
            components[componentCount] = component;
            IdxToId[componentCount] = id;
            IdToIdx[id] = componentCount;
            componentCount++;
        }

        public T Get(Int32 id)
        {
            return components[IdToIdx[id]];
        }

        public void Remove(Int32 id)
        {
            int idx = IdToIdx[id];
            int last = components.Count - 1;

            components[idx] = components[last];
            int a = IdxToId[last];

            IdToIdx[a] = idx;
            IdxToId[idx] = a;

            components.Remove(last);
            IdToIdx.Remove(id);
            IdxToId.Remove(last);
        }
    }

    class ComponentManager
    {
        Dictionary<string, IComponentArray> componentArrays;
        Dictionary<Type, int> componentTypes;
        int componentType = 0;

        public ComponentManager() { 
            componentArrays = new Dictionary<string, IComponentArray>();
        }

        private ComponentArray<T> GetComponentArray<T>()
        {
            if (componentArrays[typeof(T).Name] == null) return null;
            return (ComponentArray<T>)componentArrays[typeof(T).Name];
        }

        public void RegisterComponent<T>()
        {
            componentArrays.Add(typeof(T).Name, new ComponentArray<T>());
            componentTypes.Add(typeof(T), componentType);
            ++componentType;
        }

        public int GetComponentType<T>()
        {
            return componentTypes[typeof(T)];
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            GetComponentArray<T>().AddComponent(id, component);
        }

        public T GetComponent<T>(Int32 id)
        {
            return GetComponentArray<T>().Get(id);
        }

        public Int32 CreateEntity()
        {
            return new Node().getId();
        } 
    }
}
