﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class Node
    {
        Int32 nodeID = -1;
        static Int32 id = 0;
        public Node()
        {
            nodeID = id++;
        }
        ~Node() { }

        public Int32 getId() { return nodeID; }

        public void update()
        {

        }
    }

    interface IComponentArray {
        public void Remove(Int32 id);
    }
    
    class ComponentArray<T> : IComponentArray {
        private int componentCount = 0;
        private Dictionary<int, T> components;
        private Dictionary<int, int> IdToIdx,IdxToId;

        public ComponentArray() {
            components = new Dictionary<int, T>();
            IdToIdx = new Dictionary<int, int>();
            IdxToId = new Dictionary<int, int>();
        }

        public void AddComponent(Int32 id, T component)
        {
            if (component == null) throw new Exception("component is null");
            components[componentCount] = component;
            IdxToId[componentCount] = id;
            IdToIdx[id] = componentCount;
            componentCount++;
        }

        public T Get(Int32 id)
        {
            return components[IdToIdx[id]];
        }

        public void Remove(Int32 id)
        {
            int idx = IdToIdx[id];
            int last = components.Count - 1;

            components[idx] = components[last];
            int a = IdxToId[last];

            IdToIdx[a] = idx;
            IdxToId[idx] = a;

            components.Remove(last);
            IdToIdx.Remove(id);
            IdxToId.Remove(last);
        }
    }

    class ComponentManager
    {
        Dictionary<string, IComponentArray> componentArrays;
        Dictionary<Type, int> componentTypes;
        int componentType = 0;

        public ComponentManager() { 
            componentArrays = new Dictionary<string, IComponentArray>();
            componentTypes = new Dictionary<Type, int>();
        }

        private ComponentArray<T> GetComponentArray<T>()
        {
            if (componentArrays[typeof(T).Name] == null) return null;
            return (ComponentArray<T>)componentArrays[typeof(T).Name];
        }

        public void RegisterComponent<T>()
        {
            componentArrays.Add(typeof(T).Name, new ComponentArray<T>());
            componentTypes.Add(typeof(T), componentType);
            ++componentType;
        }

        public int GetComponentType<T>()
        {
            return componentTypes[typeof(T)];
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            GetComponentArray<T>().AddComponent(id, component);
        }

        public T GetComponent<T>(Int32 id)
        {
            return GetComponentArray<T>().Get(id);
        }

        public Int32 CreateEntity()
        {
            return new Node().getId();
        } 
    }
    class EntityManager
    {
        private List<Node> entities = new List<Node>();

        public void AddEntity(Node node)
        {
            Node[] nodes = entities.ToArray();
            Array.Resize(ref nodes, node.getId() + 1);
            nodes[node.getId()] = node;
            entities = nodes.ToList();

        }

        public Node GetEntity(Int32 id)
        {
            return entities[id];
        }
    }

    class Coordinator
    {
        private EntityManager entityManager = new EntityManager();
        private ComponentManager componentManager = new ComponentManager();

        private static Coordinator instance;

        ~Coordinator()
        {
            entityManager = null;
            componentManager = null;
        }

        public static Coordinator getInstance()
        {
            if(instance == null) instance = new Coordinator();
            return instance;
        }

        public void RegisterComponent<T>()
        {
            componentManager.RegisterComponent<T>();
        }

        public int GetComponentType<T>()
        {
            return componentManager.GetComponentType<T>();
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            componentManager.AddComponent(id, component);
        }

        public T GetComponent<T>(Int32 id)
        {
            return componentManager.GetComponent<T>(id);
        }

        public Int32 CreateEntity()
        {
            Node node = new Node();
            entityManager.AddEntity(node);
            return node.getId();
        }

        public Node GetEntity(Int32 id)
        {
            return entityManager.GetEntity(id);
        }
    }
}


