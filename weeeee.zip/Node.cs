﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;

namespace weeeee
{
    internal class Node
    {
        Int32 nodeID = -1;
        static Int32 id = 0;

        public Node()
        {
            nodeID = id++;
        }

        public Node(int num, int type, Point pos)
        {
            nodeID = id++;
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(1 * 109 + 19 * 1, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new CardProperties(num, type, new Point(pos.X,pos.Y)));
            Coordinator.getInstance().AddComponent(getId(), new Child { });
            Coordinator.getInstance().AddComponent(getId(), new Interactable());
        }
        ~Node() { }

        public Int32 getId() { return nodeID; }

        public void update()
        {

        }

        public void revealCard() { }
        public void UpdatePosition(Point point)
        {
            var properties = Coordinator.getInstance().GetComponent<CardProperties>(getId());
            var renderable = Coordinator.getInstance().GetComponent<Renderable>(getId());
            properties.pos = point;
            renderable.UVRect.X = point.X;
            renderable.UVRect.Y = point.Y;
        }

        public void ResetPosition()
        {
            var renderable = Coordinator.getInstance().GetComponent<Renderable>(getId());
            var properties = Coordinator.getInstance().GetComponent<CardProperties>(getId());
            renderable.UVRect.X = properties.pos.X;
            renderable.UVRect.Y = properties.pos.Y;
        }
    }

    partial class CardPile : Node
    {
        public CardPile() : base() { }
    }

    class CardPileA : CardPile
    {
        public enum Type
        {
            DECK=0,
            PILE
        }

        public CardPileA otherPile;
        private Type type;

        public CardPileA(Point pos, Type type) : base()
        {
            Coordinator.getInstance().AddComponent(getId(), new Interactable() { onClick = new Interactable.Click(() => { update(); }) });
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().GetComponent<Root>(getId()).SetGap(0);
            this.type = type;
        }

        public CardPileA(CardPileA otherPile, Point pos) : base()
        {
            this.otherPile = otherPile;
            otherPile.otherPile = this;
            this.type = otherPile.GetType() == Type.DECK ? Type.PILE : Type.DECK;
            Coordinator.getInstance().AddComponent(getId(), new Interactable() { onClick = new Interactable.Click(() => { this.update(); }) });
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X,pos.Y,109,153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().GetComponent<Root>(getId()).SetGap(0);

            Root.Update update = new Root.Update(() =>
            {
                var lastChild = Coordinator.getInstance().GetComponent<Root>(getId()).children.GetLastElement();
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(lastChild);
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = new Bitset();
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
        }

        public void update()
        {
            if (type == Type.DECK)
            {
                Console.WriteLine(GetRoot().children.Count);
                if(GetRoot().children.Count == 0)
                {
                    while (otherPile.GetRoot().children.Count != 0)
                    {
                        int entity = otherPile.GetRoot().children.RemoveLastElement();
                        var propertiesa = Coordinator.getInstance().GetComponent<CardProperties>(entity);
                        var renderablea = Coordinator.getInstance().GetComponent<Renderable>(entity);
                        renderablea.ImageUV.X = 1 * 109 + 19 * 1;
                        renderablea.ImageUV.Y = 4 * 153 + 4 * 13;
                        propertiesa.isRevealed = !propertiesa.isRevealed;
                        AddNode(entity);
                    }
                    return;
                }
                int card = Coordinator.getInstance().GetComponent<Root>(getId()).children.RemoveLastElement();
                if (GetRoot().children.Count == 0) Coordinator.getInstance().RemoveComponent<Child>(getId());
                else Coordinator.getInstance().RemoveComponent<Child>(GetRoot().children.GetLastElement());
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(card);
                var renderable = Coordinator.getInstance().GetComponent<Renderable>(card);
                renderable.ImageUV.X = properties.num * 109 + 19 * properties.num;
                renderable.ImageUV.Y = (int)properties.cardType * 153 + (int)properties.cardType * 13;
                properties.isRevealed = true;
                otherPile.AddNode(card);
            }
        }

        public void AddNode(Int32 entity)
        {
            if (GetRoot().children.Count != 0) Coordinator.getInstance().AddComponent(GetRoot().children.GetLastElement(), new Child { value = entity });
            else Coordinator.getInstance().AddComponent(getId(), new Child { value = entity });
            Coordinator.getInstance().GetComponent<Root>(getId()).AddToPile(entity);
            if (Coordinator.getInstance().EntityHasComponent<Parent>(entity)) Coordinator.getInstance().RemoveComponent<Parent>(entity);
            Coordinator.getInstance().AddComponent(entity, new Parent { value = getId() });
            
            var properties = Coordinator.getInstance().GetComponent<Interactable>(entity);
            properties.onClick = new Interactable.Click(() =>
            {

                update();
            });
        }

        public void revealCard() { }

        public Root GetRoot()
        {
            return Coordinator.getInstance().GetComponent<Root>(getId());
        }

        public Type GetType() { return type; }
    }

    class CardPileB : CardPile
    {
        public CardPileB(Point pos) {
            Coordinator.getInstance().AddComponent(getId(), new Root(new Rectangle(pos.X, pos.Y, 109, 153)));
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(2 * 109 + 19 * 2, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153)));
            Root.Update update = new Root.Update(() =>
            {
                var lastChild = Coordinator.getInstance().GetComponent<Root>(getId()).children.GetLastElement();
                var properties = Coordinator.getInstance().GetComponent<CardProperties>(lastChild);
                Coordinator.getInstance().GetComponent<Root>(getId()).bitset = (properties.color == 0 ? properties.colorBitset << 1 : properties.colorBitset >> 1) + (properties.numBitset << 1);
            });
            Coordinator.getInstance().GetComponent<Root>(getId()).UpdateSignature = update;
        }

        public void AddNode(Int32 entity)
        {
            if (GetRoot().children.Count != 0) Coordinator.getInstance().AddComponent(GetRoot().children.GetLastElement(), new Child { value = entity });
            else Coordinator.getInstance().AddComponent(getId(), new Child { value = entity });
            Coordinator.getInstance().GetComponent<Root>(getId()).AddToPile(entity);
            if (Coordinator.getInstance().EntityHasComponent<Parent>(entity)) Coordinator.getInstance().RemoveComponent<Parent>(entity);
            Coordinator.getInstance().AddComponent(entity, new Parent { value = getId() });
            GetRoot().UpdateSignature();
        }

        public Root GetRoot()
        {
            return Coordinator.getInstance().GetComponent<Root>(getId());
        }
    }

    class CardPileC : CardPile { 

    }


    interface IComponentArray {
        public void Remove(Int32 id);
    }
    
    class ComponentArray<T> : IComponentArray {
        private int componentCount = 0;
        private Dictionary<int, T> components;
        private Dictionary<int, int> IdToIdx,IdxToId;

        public ComponentArray() {
            components = new Dictionary<int, T>();
            IdToIdx = new Dictionary<int, int>();
            IdxToId = new Dictionary<int, int>();
        }

        public void AddComponent(Int32 id, T component)
        {
            if (component == null) throw new Exception("component is null");
            components[componentCount] = component;
            IdxToId[componentCount] = id;
            IdToIdx[id] = componentCount;
            componentCount++;
        }

        public T Get(Int32 id)
        {
            return components[IdToIdx[id]];
        }

        public void Remove(Int32 id)
        {
            int idx = IdToIdx[id];
            int last = components.Count - 1;

            components[idx] = components[last];
            int a = IdxToId[last];

            IdToIdx[a] = idx;
            IdxToId[idx] = a;

            components.Remove(last);
            IdToIdx.Remove(id);
            IdxToId.Remove(last);
            componentCount--;
        }

        public bool Has(Int32 id)
        {
            return IdToIdx.ContainsKey(id);
        }
    }

    class ComponentManager
    {
        Dictionary<string, IComponentArray> componentArrays;
        Dictionary<Type, int> componentTypes;
        int componentType = 0;

        public ComponentManager() { 
            componentArrays = new Dictionary<string, IComponentArray>();
            componentTypes = new Dictionary<Type, int>();
        }

        private ComponentArray<T> GetComponentArray<T>()
        {
            if (componentArrays[typeof(T).Name] == null) return null;
            return (ComponentArray<T>)componentArrays[typeof(T).Name];
        }

        public void RegisterComponent<T>()
        {
            componentArrays.Add(typeof(T).Name, new ComponentArray<T>());
            componentTypes.Add(typeof(T), componentType);
            ++componentType;
        }

        public int GetComponentType<T>()
        {
            return componentTypes[typeof(T)];
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            GetComponentArray<T>().AddComponent(id, component);
        }

        public T GetComponent<T>(Int32 id)
        {
            return GetComponentArray<T>().Get(id);
        }

        public Int32 CreateEntity()
        {
            return new Node().getId();
        }
        
        public bool EntityHasComponent<T>(Int32 id)
        {
            return GetComponentArray<T>().Has(id);
        }

        public void RemoveComponent<T>(Int32 id)
        {
            GetComponentArray<T>().Remove(id);
        }
    }
    class EntityManager
    {
        private List<Node> entities = new List<Node>();
        private List<Bitset> signatures = new List<Bitset>();

        public void AddEntity(Node node)
        {
            Node[] nodes = entities.ToArray();
            Array.Resize(ref nodes, node.getId() + 1);
            nodes[node.getId()] = node;
            entities = nodes.ToList();

        }

        public Node GetEntity(Int32 id)
        {
            return entities[id];
        }

        public List<Node> GetEntities() { return entities; }

        public void SetSignature(Int32 entity, Bitset signature)
        {
            signatures[entity] = signature;
        }

        public Bitset GetSignature(Int32 entity)
        {
            if (entity >= signatures.Count) for (int i = 0; i <= entity; i++) signatures.Add(new Bitset());
            return signatures[entity];
        }
    }

    class Coordinator
    {
        private EntityManager entityManager = new EntityManager();
        private ComponentManager componentManager = new ComponentManager();
        private SystemManager systemManager = new SystemManager();

        private static Coordinator instance;

        ~Coordinator()
        {
            instance = null;
        }

        public static Coordinator getInstance()
        {
            if(instance == null) instance = new Coordinator();
            return instance;
        }

        public void RegisterComponent<T>()
        {
            componentManager.RegisterComponent<T>();
        }

        public int GetComponentType<T>()
        {
            return componentManager.GetComponentType<T>();
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            componentManager.AddComponent(id, component);
            Bitset bitset = entityManager.GetSignature(id);
            bitset[componentManager.GetComponentType<T>()] = true;
            entityManager.SetSignature(id, bitset);
            systemManager.UpdateEntitySystem(id, bitset);
        }

        public T GetComponent<T>(Int32 id)
        {
            return componentManager.GetComponent<T>(id);
        }

        public Int32 CreateEntity()
        {
            Node node = new Node();
            entityManager.AddEntity(node);
            return node.getId();
        }

        public Int32 CreateEntity(int num, int type, Point pos)
        {
            Node node = new Node(num, type, pos);
            entityManager.AddEntity(node);
            return node.getId();
        }

        public Node GetEntity(Int32 id)
        {
            return entityManager.GetEntity(id);
        }

        public List<Node> GetEntities() { return entityManager.GetEntities(); }

        public T RegisterSystem<T>() where T : SignatureSystem, new()
        {
            return systemManager.RegisterSystem<T>();
        }

        public void SetSystemSignature<T>(Bitset signature)
        {
            systemManager.SetSystemSignature<T>(signature);
        }

        public bool EntityHasComponent<T>(Int32 id)
        {
            return componentManager.EntityHasComponent<T>(id);
        }

        public void RemoveComponent<T>(Int32 id)
        {
            Bitset signature = entityManager.GetSignature(id);
            componentManager.RemoveComponent<T>(id);
            signature[componentManager.GetComponentType<T>()] = false;
            entityManager.SetSignature(id,signature);
            systemManager.UpdateEntitySystem(id, signature);
        }
    }

    class SignatureSystem
    {
        public HashSet<Int32> entities;

        public SignatureSystem() { entities = new HashSet<Int32>(); }
    }

    class SystemManager
    {
        private Dictionary<Type, SignatureSystem> systems;
        private Dictionary<Type, Bitset> signatures;

        public SystemManager()
        {
            systems = new Dictionary<Type, SignatureSystem>();
            signatures = new Dictionary<Type, Bitset>();
        }

        public T RegisterSystem<T>() where T : SignatureSystem, new()
        {
            T system = new T();
            systems[typeof(T)] = system;
            return system;
        }

        public void UpdateEntitySystem(Int32 entityID, Bitset updatedSignature)
        {
            foreach(KeyValuePair<Type, SignatureSystem> p in systems)
            {
                if ((updatedSignature & signatures[p.Key]) == signatures[p.Key])
                {
                    p.Value.entities.Add(entityID);
                    //Console.WriteLine("hello");
                }
                else p.Value.entities.Remove(entityID);
            }
        }

        public void SetSystemSignature<T>(Bitset signature)
        {
            signatures[typeof(T)] = signature;
        }
    }
}


