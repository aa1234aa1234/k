﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class RenderSystem : SignatureSystem
    {
        List<int> renderQueue = new();

        public RenderSystem()
        {
            Initialize();
        }

        public void Initialize()
        {
            Bitset signature = new Bitset();
            signature[Coordinator.getInstance().GetComponentType<Renderable>()] = true;
            Coordinator.getInstance().SetSystemSignature<RenderSystem>(signature);
            for (int i = 0; i < entities.ToArray()[entities.Count - 1]; i++) { renderQueue.Add(-1); }
        }

        public void Update(Graphics g)
        {
            foreach (var p in entities)
            {
                Coordinator.getInstance().GetComponent<Renderable>(p).render(g);
            }
            renderQueue.Clear();
            for (int i = 0; i < entities.ToArray()[entities.Count - 1]; i++) { renderQueue.Add(-1); }
            foreach (var p in entities) renderQueue[p] = p;
        }
    }
}
