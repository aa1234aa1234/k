﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class RenderSystem
    {
        private Coordinator coordinator;
        public List<int> renderQueue = new();

        public RenderSystem()
        {
            //Initialize();
            coordinator = Coordinator.getInstance();
        }

        public void Update(Graphics g)
        {
            foreach (var p in renderQueue)
            {
                coordinator.GetComponent<Renderable>(p).render(g);
            }
        }
    }

    class RenderQueueUpdate : SignatureSystem
    {
        private Coordinator coordinator;
        public RenderQueueUpdate()
        {
            coordinator = Coordinator.getInstance();
            Initialize();
            
        }

        public void Initialize()
        {
            Bitset signature = new ();
            signature[coordinator.GetComponentType<Root>()] = true;
            signature[coordinator.GetComponentType<Renderable>()] = true;
            coordinator.SetSystemSignature<RenderQueueUpdate>(signature);
        }

        public void Update(List<int> renderQueue)
        {
            foreach(var p in entities)
            {
                renderQueue.Add(p);
            }
            foreach (var p in entities)
            {
                renderQueue.AddRange(coordinator.GetComponent<Root>(p).children);
            }
        }
    }

    class TestSystem : SignatureSystem
    {
        private Coordinator coordinator;
        public TestSystem()
        {
            coordinator = Coordinator.getInstance();
            Initialize();
            
        }

        void Initialize()
        {
            Bitset signature = new();
            signature[coordinator.GetComponentType<Selected>()] = true;
            coordinator.SetSystemSignature<TestSystem>(signature);
        }

        public void Update(List<int> renderQueue)
        {
            if (entities.Count == 0) return;
            foreach(var p in entities)
            {
                renderQueue.Remove(p);
                renderQueue.Add(p);
            }
            int a = entities.First();
            
        }
    }

    class UpdateSystem : SignatureSystem
    {
        private Coordinator coordinator;
        public UpdateSystem()
        {
            coordinator = Coordinator.getInstance();
            Initialize();
            
        }

        void Initialize()
        {
            Bitset signature = new();
            signature[coordinator.GetComponentType<Update>()] = true;
            coordinator.SetSystemSignature<UpdateSystem>(signature);
        }

        public CardPile Update(HashSet<CardPile> parents, HashSet<Point> update, List<CardPile> rootNodes)
        {
            if (entities.Count == 0) return null;
            List<int> a = new();
            CardPile par=null;
            foreach (var p in entities)
            {
                a.Add(p);
                if (!coordinator.EntityHasComponent<Parent>(p)) par = (CardPile)coordinator.GetEntity(p);
                else par = (CardPile)coordinator.GetEntity(coordinator.GetComponent<Parent>(p).value);
                for (int i = 0; i < rootNodes.Count; i++)
                {
                    if (rootNodes[i].GetRoot().bounds.IntersectsWith(coordinator.GetComponent<Renderable>(p).UVRect)) parents.Add(rootNodes[i]);
                }
                //parents.Add(par);
                if (coordinator.EntityHasComponent<Root>(p)) continue;
                if(coordinator.GetComponent<CardProperties>(p).lastpos.X != 0) update.Add(coordinator.GetComponent<CardProperties>(p).lastpos);
            }

            a.Reverse();
            foreach (var k in a) coordinator.RemoveComponent<Update>(k);
            return par;
        }
    }
}
