﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class RenderSystem
    {
        public List<int> renderQueue = new();

        public RenderSystem()
        {
            //Initialize();
        }

        public void Update(Graphics g)
        {
            foreach (var p in renderQueue)
            {
                Coordinator.getInstance().GetComponent<Renderable>(p).render(g);
            }
        }
    }

    class RenderQueueUpdate : SignatureSystem
    {
        public RenderQueueUpdate()
        {
            Initialize();
        }

        public void Initialize()
        {
            Bitset signature = new ();
            signature[Coordinator.getInstance().GetComponentType<Root>()] = true;
            signature[Coordinator.getInstance().GetComponentType<Renderable>()] = true;
            Coordinator.getInstance().SetSystemSignature<RenderQueueUpdate>(signature);
        }

        public void Update(List<int> renderQueue)
        {
            foreach(var p in entities)
            {
                renderQueue.Add(p);
            }
            foreach (var p in entities)
            {
                renderQueue.AddRange(Coordinator.getInstance().GetComponent<Root>(p).children);
            }
        }
    }

    class TestSystem : SignatureSystem
    {
        public TestSystem()
        {
            Initialize();
        }

        void Initialize()
        {
            Bitset signature = new();
            signature[Coordinator.getInstance().GetComponentType<Selected>()] = true;
            Coordinator.getInstance().SetSystemSignature<TestSystem>(signature);
        }

        public void Update(List<int> renderQueue)
        {
            if (entities.Count == 0) return;
            foreach(var p in entities)
            {
                renderQueue.Remove(p);
                renderQueue.Add(p);
            }
            int a = entities.First();
            
        }
    }

    class UpdateSystem : SignatureSystem
    {
        public UpdateSystem()
        {
            Initialize();
        }

        void Initialize()
        {
            Bitset signature = new();
            signature[Coordinator.getInstance().GetComponentType<Update>()] = true;
            Coordinator.getInstance().SetSystemSignature<UpdateSystem>(signature);
        }

        public CardPile Update(HashSet<CardPile> parents, HashSet<Point> update, List<CardPile> rootNodes)
        {
            if (entities.Count == 0) return null;
            List<int> a = new();
            CardPile par=null;
            foreach (var p in entities)
            {
                a.Add(p);
                if (!Coordinator.getInstance().EntityHasComponent<Parent>(p)) par = (CardPile)Coordinator.getInstance().GetEntity(p);
                else par = (CardPile)Coordinator.getInstance().GetEntity(Coordinator.getInstance().GetComponent<Parent>(p).value);
                for (int i = 0; i < rootNodes.Count; i++)
                {
                    if (rootNodes[i].GetRoot().bounds.IntersectsWith(Coordinator.getInstance().GetComponent<Renderable>(p).UVRect)) parents.Add(rootNodes[i]);
                }
                //parents.Add(par);
                if(Coordinator.getInstance().GetComponent<CardProperties>(p).lastpos.X != 0) update.Add(Coordinator.getInstance().GetComponent<CardProperties>(p).lastpos);
            }

            a.Reverse();
            foreach (var k in a) Coordinator.getInstance().RemoveComponent<Update>(k);
            return par;
        }
    }
}
