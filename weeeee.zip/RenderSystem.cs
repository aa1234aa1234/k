﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class RenderSystem : SignatureSystem
    {
        public RenderSystem()
        {
            Initialize();
        }

        public void Initialize()
        {
            Bitset signature = new Bitset();
            signature[Coordinator.getInstance().GetComponentType<Renderable>()] = true;
            Coordinator.getInstance().SetSystemSignature<RenderSystem>(signature);
        }

        public void Update(Graphics g)
        {
            foreach(var p in entities)
            {
                Coordinator.getInstance().GetComponent<Renderable>(p).render(g);
            }
        }
    }
}
