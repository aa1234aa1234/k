﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace weeeee
{
    internal class RenderSystem
    {
        public List<int> renderQueue = new();

        public RenderSystem()
        {
            //Initialize();
        }

        public void Update(Graphics g)
        {
            foreach (var p in renderQueue)
            {
                Coordinator.getInstance().GetComponent<Renderable>(p).render(g);
            }
            renderQueue.Clear();
        }
    }

    class RenderQueueUpdate : SignatureSystem
    {
        public RenderQueueUpdate()
        {
            Initialize();
        }

        public void Initialize()
        {
            Bitset signature = new ();
            signature[Coordinator.getInstance().GetComponentType<Root>()] = true;
            signature[Coordinator.getInstance().GetComponentType<Renderable>()] = true;
            Coordinator.getInstance().SetSystemSignature<RenderQueueUpdate>(signature);
        }

        public void Update(ref List<int> renderQueue)
        {
            foreach(var p in entities)
            {
                renderQueue.Add(p);
            }
            foreach (var p in entities)
            {
                renderQueue.AddRange(Coordinator.getInstance().GetComponent<Root>(p).children);
            }
        }
    }
}
