namespace weeeee
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            System.Windows.Forms.Application.Run(new Form1());
        }


        public static int add(this Point pt, int a, int b)
        {
            pt.X = a;
            pt.Y = b;
            return a + b;
        }

        public static int GetLastElement(this List<int> list)
        {
            return list[list.Count - 1];
        }

        public static int RemoveLastElement(this List<int> list)
        {
            int a = GetLastElement(list);
            list.Remove(list.Count - 1);
            return a;
        }

        public static int RemoveFirstElement(this List<int> list)
        {
            int a = list[0];
            list.RemoveAt(0);
            return a;
        }
    }
}