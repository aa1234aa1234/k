namespace weeeee
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            System.Windows.Forms.Application.Run(new Form1());
        }


        public static int add(this Point pt, int a, int b)
        {
            pt.X = a;
            pt.Y = b;
            return a + b;
        }

        public static int GetLastElement(this List<int> list)
        {
            return list[list.Count - 1];
        }

        public static int RemoveLastElement(this List<int> list)
        {
            int a = GetLastElement(list);
            list.RemoveAt(list.Count - 1);
            return a;
        }

        public static int RemoveFirstElement(this List<int> list)
        {
            int a = list[0];
            list.RemoveAt(0);
            return a;
        }

        public static void Shuffle<T>(ref List<T> list)
        {
            var rand = new Random();
            for (int i = 0; i<list.Count-1; ++i)
            {
                Swap(ref list, i, rand.Next(i, list.Count));
            }
        }

        public static void Swap<T>(ref List<T> list, int a, int b)
        {
            var tmp = list[a];
            list[a] = list[b];
            list[b] = tmp;
        }

        public static T RemoveLastElement<T>(ref List<T> list)
        {
            T a = list[list.Count-1];
            list.RemoveAt(list.Count - 1);
            return a;
        }
    }
}