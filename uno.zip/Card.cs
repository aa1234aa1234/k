﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uno;
using uno.ecs;

namespace cardgame
{
    internal class Card : Entity
    {
        public Card() { }
        public Card(int num, int type, Point pos)
        {
            Coordinator.getInstance().AddComponent(getId(), new CardProperties(num, type, pos));
            Coordinator.getInstance().AddComponent(getId(), new Clickable());
            Coordinator.getInstance().AddComponent(getId(), new Renderable(new Rectangle(1 * 109 + 19 * 1, 153 * 4 + 13 * 4, 109, 153), new Rectangle(pos.X, pos.Y, 109, 153), 1, 4));
        }

        public void SetPosition(Point pos) {
            Coordinator.getInstance().GetComponent<CardProperties>(getId()).pos = pos;
            var renderable = Coordinator.getInstance().GetComponent<Renderable>(getId());
            renderable.UVRect.X = pos.X;
            renderable.UVRect.Y = pos.Y;
        }

        public CardProperties GetProperties() { return Coordinator.getInstance().GetComponent<CardProperties>(getId());  }
    }
}
