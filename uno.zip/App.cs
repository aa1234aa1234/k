﻿using cardgame;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uno.ecs;

namespace uno
{

    class GlobalState
    {
        public int playerCount;
        public int turnCount;
        public int turnOrder;
        public int CurrentTurn;

        public void IncrementTurn()
        {
            turnCount += turnOrder;
            turnCount %= playerCount;
        }
    }

    internal class App
    {
        private List<Card> cardPool = new();
        private List<Player> playerList = new();
        private GlobalState globalState;
        private System.Windows.Forms.Timer timer;

        private Graphics cacheGraphics;
        private Bitmap backBuffer;


        public App() { }

        public App(int width, int height)
        {
            Initialize(width, height);
        }

        public void Initialize(int width, int height)
        {
            for(int i = 0; i<10; i++)
            {
                for(int j = 0; j<4; j++)
                {
                    cardPool.Add(new Card(i, j, new Point(0, 0)));
                }
            }
            for(int i = 0; i<2; i++)
            {
                playerList.Add(new Player());
            }

            backBuffer = new Bitmap(width, height);
            cacheGraphics = Graphics.FromImage(backBuffer);
            cacheGraphics.DrawImageUnscaled(ImageUtils.getInstance().getBackground(), 0, 0);
        }

        public void run()
        {
            timer.Interval = 16;
            timer.Tick += (sender, e) =>
            {
                


                
            };
        }

        public void render(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImageUnscaled(backBuffer, 0, 0);
        }
    }
}
