﻿using cardgame;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uno.ecs;

namespace uno
{

    class GlobalState
    {
        public int playerCount;
        public int turnCount;
        public int turnOrder;
        public int CurrentTurn;
        public int cardDebt;
        public Bitset currentShape=new(4);
        public Bitset currentNum=new(13);

        public void IncrementTurn()
        {
            turnCount += turnOrder;
            turnCount %= playerCount;
        }
    }

    internal class App
    {
        private List<Card> cardPool = new();
        private List<Player> playerList = new();
        private GlobalState globalState = new();
        private System.Windows.Forms.Timer timer;
        private int playerIdx;

        private Graphics cacheGraphics;
        private Bitmap backBuffer;
        private ClickSystem clickSystem;

        private Coordinator coordinator;

        public App() { }

        public App(int width, int height)
        {
            coordinator = Coordinator.getInstance();
            Initialize(width, height);
        }

        public void Initialize(int width, int height)
        {
            coordinator.RegisterComponent<CardProperties>();
            coordinator.RegisterComponent<ChildComponent>();
            coordinator.RegisterComponent<Renderable>();
            coordinator.RegisterComponent<Clickable>();

            for(int i = 0; i<13; i++)
            {
                for(int j = 0; j<4; j++)
                {
                    Card card = new Card(i, j, new Point(500, 300));
                    var properties = coordinator.GetComponent<CardProperties>(card.getId());
                    switch(i)
                    {
                        case 12:
                            break;
                        case 11:
                            break;
                        case 0:
                            properties.onUse = new CardProperties.UseCard(() =>
                            {
                                globalState.cardDebt += 3;
                            });
                            if (j == 2)
                            {
                                properties.onUse = new CardProperties.UseCard(() =>
                                {
                                    globalState.cardDebt += 5;
                                });
                            }
                            break;
                        case 1:
                            properties.onUse = new CardProperties.UseCard(() =>
                            {
                                globalState.cardDebt += 2;
                            });
                            break;
                        case 6:

                            break;

                    }
                    cardPool.Add(card);
                }
            }
            Program.Shuffle(ref cardPool);
            
            for(int i = 0; i<2; i++)
            {
                playerList.Add(new Player());
                for(int j = 0; j<7; j++)
                {
                    coordinator.GetComponent<ChildComponent>(playerList[i].getId()).child.Add(Program.RemoveLastElement(ref cardPool));
                }
            }
            playerIdx = 0;
            backBuffer = new Bitmap(width, height);
            cacheGraphics = Graphics.FromImage(backBuffer);
            cacheGraphics.DrawImageUnscaled(ImageUtils.getInstance().getBackground(), 0, 0);

            clickSystem = new();
        }

        public void handleInput(object sender, MouseEventArgs e)
        {
            if (globalState.turnCount == playerIdx) clickSystem.Update();
        }

        public void run(Form1 form)
        {

            timer = new();

            timer.Interval = 16;
            timer.Tick += (sender, e) =>
            {
                cacheGraphics.Clear(Color.Black);
                cacheGraphics.DrawImageUnscaled(ImageUtils.getInstance().getBackground(), 0, 0);
                if(cardPool.Count >= 2)
                {
                    coordinator.GetComponent<Renderable>(cardPool[0].getId()).render(cacheGraphics);
                    coordinator.GetComponent<Renderable>(cardPool[1].getId()).render(cacheGraphics);
                }
                else cardPool.ForEach((p) => { coordinator.GetComponent<Renderable>(p.getId()).render(cacheGraphics); });

                form.Invalidate();
            };

            timer.Start();
        }

        public void render(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImageUnscaled(backBuffer, 0, 0);
        }
    }
}
