﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uno.ecs;

namespace uno
{
    struct ChildComponent
    {
        public List<Entity> child=new();

        public ChildComponent() { }
    }

    class Renderable
    {
        public Rectangle ImageUV, UVRect;
        public int x, y;
        public Renderable(Rectangle imageUV, Rectangle uVRect, int x, int y)
        {
            ImageUV = imageUV;
            UVRect = uVRect;
            this.x = x;
            this.y = y;
        }

        public void render(Graphics g, int x = -1, int y = -1)
        {
            g.DrawImageUnscaled(ImageUtils.getInstance().getCardBitmap(this.x, this.y), x == -1 ? UVRect.X : x, y == -1 ? UVRect.Y : y);
        }
    }
}
