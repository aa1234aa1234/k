using cardgame;

namespace uno
{
    public partial class Form1 : Form
    {
        private App app;
        private Point lastClick;
        private bool firstClick = true;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            app = new App(this.Width, this.Height);
            this.MouseMove += (sender, e) => {
                Input.getInstance().setMousePos(e.Location);

                if (e.Button == MouseButtons.Left)
                {
                    Input.getInstance().setMouseDelta(new Point(lastClick.X - Input.getInstance().getMousePos().X, lastClick.Y - Input.getInstance().getMousePos().Y));
                    Input.getInstance().setEventType(Input.EventType.MOUSEDRAG);
                }
                else Input.getInstance().setEventType(Input.EventType.MOUSEMOVE);
                lastClick = e.Location;
                app.handleInput(sender, e);
            };
            this.MouseDown += (sender, e) => {
                Input.getInstance().setEventType(Input.EventType.MOUSEDOWN);
                switch (e.Button)
                {
                    case MouseButtons.Left:
                        Input.getInstance().getMouseDown()[Input.MouseType.LEFT] = true;
                        break;
                    case MouseButtons.Right:
                        Input.getInstance().getMouseDown()[Input.MouseType.RIGHT] = true;
                        break;
                    default:
                        Input.getInstance().getMouseDown()[Input.MouseType.LEFT] = true;
                        break;
                }


                if (firstClick)
                {
                    lastClick = e.Location;
                    firstClick = false;
                }
                app.handleInput(sender, e);
            };
            this.MouseUp += (sender, e) => {
                Input.getInstance().setEventType(Input.EventType.MOUSEUP);
                switch (e.Button)
                {
                    case MouseButtons.Left:
                        Input.getInstance().getMouseDown()[Input.MouseType.LEFT] = false;
                        break;
                    case MouseButtons.Right:
                        Input.getInstance().getMouseDown()[Input.MouseType.RIGHT] = false;
                        break;
                    default:
                        Input.getInstance().getMouseDown()[Input.MouseType.LEFT] = false;
                        break;
                }
                app.handleInput(sender, e);
            };

            this.Paint += (sender, e) => { app.render(sender, e); };
            this.SetStyle(ControlStyles.AllPaintingInWmPaint |
              ControlStyles.UserPaint |
              ControlStyles.OptimizedDoubleBuffer, true);
            this.UpdateStyles();

            app.run(this);
        }
    }
}
