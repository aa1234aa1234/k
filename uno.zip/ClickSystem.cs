﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uno;
using uno.ecs;

namespace cardgame
{
    internal class ClickSystem : SignatureSystem
    {
        private Coordinator coordinator;

        public ClickSystem() {
            coordinator = Coordinator.getInstance();
            Initialize();
        }

        public void Initialize()
        {
            Bitset signature = new Bitset();
            signature[coordinator.GetComponentType<Clickable>()] = true;
            signature[coordinator.GetComponentType<Renderable>()] = true;
            coordinator.SetSystemSignature<ClickSystem>(signature);
        }

        public void Update()
        {
            if (Input.getInstance().getEventType() != Input.EventType.MOUSEDOWN) return;
            foreach(var p in entities)
            {
                if(coordinator.GetComponent<Renderable>(p).UVRect.Contains(Input.getInstance().getMousePos()))
                {
                    if(coordinator.EntityHasComponent<CardProperties>(p))
                    {
                        coordinator.GetComponent<CardProperties>(p).onUse();
                    }
                    coordinator.GetComponent<Clickable>(p).onClick();
                }
            }
        }
    }
}
