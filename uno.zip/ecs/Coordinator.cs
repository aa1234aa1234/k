﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace uno.ecs
{
    class Coordinator
    {
        private EntityManager entityManager = new EntityManager();
        private ComponentManager componentManager = new ComponentManager();
        private SystemManager systemManager = new SystemManager();

        private static Coordinator instance;

        ~Coordinator()
        {
            instance = null;
        }

        public static Coordinator getInstance()
        {
            if (instance == null) instance = new Coordinator();
            return instance;
        }

        public void RegisterComponent<T>()
        {
            componentManager.RegisterComponent<T>();
        }

        public int GetComponentType<T>()
        {
            return componentManager.GetComponentType<T>();
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            if (EntityHasComponent<T>(id)) return;
            componentManager.AddComponent(id, component);
            Bitset bitset = entityManager.GetSignature(id);
            bitset[componentManager.GetComponentType<T>()] = true;
            entityManager.SetSignature(id, bitset);
            systemManager.UpdateEntitySystem(id, bitset);
        }

        public T GetComponent<T>(Int32 id)
        {
            return componentManager.GetComponent<T>(id);
        }

        public Int32 CreateEntity()
        {
            Entity node = new Entity();
            entityManager.AddEntity(node);
            return node.getId();
        }

        public void AddEntity(Entity node)
        {
            entityManager.AddEntity(node);
        }

        public Entity GetEntity(Int32 id)
        {
            return entityManager.GetEntity(id);
        }

        public List<Entity> GetEntities() { return entityManager.GetEntities(); }

        public T RegisterSystem<T>() where T : SignatureSystem, new()
        {
            return systemManager.RegisterSystem<T>();
        }

        public void SetSystemSignature<T>(Bitset signature)
        {
            systemManager.SetSystemSignature<T>(signature);
        }

        public bool EntityHasComponent<T>(Int32 id)
        {
            return componentManager.EntityHasComponent<T>(id);
        }

        public void RemoveComponent<T>(Int32 id)
        {
            Bitset signature = entityManager.GetSignature(id);
            componentManager.RemoveComponent<T>(id);
            signature[componentManager.GetComponentType<T>()] = false;
            entityManager.SetSignature(id, signature);
            systemManager.UpdateEntitySystem(id, signature);
        }
    }
}
