﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uno.ecs
{
    interface IComponentArray
    {
        public void Remove(Int32 id);
    }

    class ComponentArray<T> : IComponentArray
    {
        private int componentCount = 0;
        private Dictionary<int, T> components;
        private Dictionary<int, int> IdToIdx, IdxToId;

        public ComponentArray()
        {
            components = new Dictionary<int, T>();
            IdToIdx = new Dictionary<int, int>();
            IdxToId = new Dictionary<int, int>();
        }

        public void AddComponent(Int32 id, T component)
        {
            if (component == null) throw new Exception("component is null");
            components[componentCount] = component;
            IdxToId[componentCount] = id;
            IdToIdx[id] = componentCount;
            componentCount++;
        }

        public T Get(Int32 id)
        {
            return components[IdToIdx[id]];
        }

        public void Remove(Int32 id)
        {
            if (!IdToIdx.ContainsKey(id)) return;
            int idx = IdToIdx[id];
            int last = components.Count - 1;

            components[idx] = components[last];
            int a = IdxToId[last];

            IdToIdx[a] = idx;
            IdxToId[idx] = a;

            components.Remove(last);
            IdToIdx.Remove(id);
            IdxToId.Remove(last);
            componentCount--;
        }

        public bool Has(Int32 id)
        {
            return IdToIdx.ContainsKey(id);
        }
    }
}
