﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uno.ecs
{
    internal class Entity
    {
        private static int id;
        private int Id;

        public Entity()
        {
            Id = ++id;
            Coordinator.getInstance().AddEntity(this);
        }

        public int getId() { return Id; }

        public virtual void render() { }
    }


}
