﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace uno.ecs
{
    class ComponentManager
    {
        Dictionary<string, IComponentArray> componentArrays;
        Dictionary<Type, int> componentTypes;
        int componentType = 0;

        public ComponentManager()
        {
            componentArrays = new Dictionary<string, IComponentArray>();
            componentTypes = new Dictionary<Type, int>();
        }

        private ComponentArray<T> GetComponentArray<T>()
        {
            if (componentArrays[typeof(T).Name] == null) return null;
            return (ComponentArray<T>)componentArrays[typeof(T).Name];
        }

        public void RegisterComponent<T>()
        {
            componentArrays.Add(typeof(T).Name, new ComponentArray<T>());
            componentTypes.Add(typeof(T), componentType);
            ++componentType;
        }

        public int GetComponentType<T>()
        {
            return componentTypes[typeof(T)];
        }

        public void AddComponent<T>(Int32 id, T component)
        {
            GetComponentArray<T>().AddComponent(id, component);
        }

        public T GetComponent<T>(Int32 id)
        {
            return GetComponentArray<T>().Get(id);
        }

        public Int32 CreateEntity()
        {
            return new Entity().getId();
        }

        public bool EntityHasComponent<T>(Int32 id)
        {
            return GetComponentArray<T>().Has(id);
        }

        public void RemoveComponent<T>(Int32 id)
        {
            GetComponentArray<T>().Remove(id);
        }
    }
}
