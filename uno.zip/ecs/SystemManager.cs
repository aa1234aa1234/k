﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uno.ecs
{
    class SystemManager
    {
        private Dictionary<Type, SignatureSystem> systems;
        private Dictionary<Type, Bitset> signatures;

        public SystemManager()
        {
            systems = new Dictionary<Type, SignatureSystem>();
            signatures = new Dictionary<Type, Bitset>();
        }

        public T RegisterSystem<T>() where T : SignatureSystem, new()
        {
            T system = new T();
            systems[typeof(T)] = system;
            return system;
        }

        public void UpdateEntitySystem(Int32 entityID, Bitset updatedSignature)
        {
            foreach (KeyValuePair<Type, SignatureSystem> p in systems)
            {
                if ((updatedSignature & signatures[p.Key]) == signatures[p.Key])
                {
                    p.Value.entities.Add(entityID);
                    //Console.WriteLine("hello");
                }
                else p.Value.entities.Remove(entityID);
            }
        }

        public void SetSystemSignature<T>(Bitset signature)
        {
            signatures[typeof(T)] = signature;
        }
    }
}
