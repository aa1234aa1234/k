﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace uno.ecs
{
    class EntityManager
    {
        private List<Entity> entities = new List<Entity>();
        private List<Bitset> signatures = new List<Bitset>();

        public void AddEntity(Entity node)
        {
            Entity[] nodes = entities.ToArray();
            Array.Resize(ref nodes, node.getId() + 1);
            nodes[node.getId()] = node;
            entities = nodes.ToList();

        }

        public Entity GetEntity(Int32 id)
        {
            return entities[id];
        }

        public List<Entity> GetEntities() { return entities; }

        public void SetSignature(Int32 entity, Bitset signature)
        {
            signatures[entity] = signature;
        }

        public Bitset GetSignature(Int32 entity)
        {
            if (entity >= signatures.Count) for (int i = 0; i <= entity; i++) signatures.Add(new Bitset());
            return signatures[entity];
        }
    }
}
