﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uno.ecs
{
    internal class SignatureSystem
    {
        public HashSet<Int32> entities;

        public SignatureSystem() { entities = new HashSet<Int32>(); }
    }
}
