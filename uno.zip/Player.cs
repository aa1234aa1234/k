﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using uno;
using uno.ecs;

namespace cardgame
{
    internal class Player : Entity
    {
        public Player() {
            Coordinator.getInstance().AddComponent(getId(), new ChildComponent { });

        }
    }
}
