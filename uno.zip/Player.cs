﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using uno;
using uno.ecs;

namespace cardgame
{
    internal class Player : Entity
    {
        private List<Entity> child;
        public Player() {
            Coordinator.getInstance().AddComponent(getId(), new ChildComponent { });
            child = Coordinator.getInstance().GetComponent<ChildComponent>(getId()).child;
        }

        public void renderCards(Graphics graphics)
        {
            child.ForEach(p => { Coordinator.getInstance().GetComponent<Renderable>(p.getId()).render(graphics); });
        }

        public void addCard(Card card) {
            if(child.Count == 0)
            {
                card.GetProperties().pos = new Point(540, 500);
            }
            else
            {
                //for(int i = 0; i<)
            }
        }
    }
}
