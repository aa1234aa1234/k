#include "UIContext.h"

UIContext::UIContext() {
	shader = new Shader("shader/vertex2.glsl", "shader/frag2.glsl");
	float ndc[] = { 
		1.0, 1.0 ,
		1.0,-1.0, 
		-1.0,1.0, 
		-1.0,-1.0, 
		1.0,-1.0, 
		-1.0,1.0,
	};
	glGenVertexArrays(1, &vao);
	glGenBuffers(1, &vbo);
	glGenBuffers(1, &instancevbo);
	glBindVertexArray(vao);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(ndc), ndc, GL_STATIC_DRAW);
	
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, instancevbo);
	glBufferData(GL_ARRAY_BUFFER, MAX_COMPONENTS * sizeof(Element), NULL, GL_DYNAMIC_DRAW);
	
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)0);
	glVertexAttribDivisor(1, 1);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)(offsetof(Element, color)));
	glVertexAttribDivisor(2, 1);
	glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)(offsetof(Element, size)));
	glVertexAttribDivisor(3, 1);
	glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, sizeof(Element), (void*)(offsetof(Element, id)));
	glVertexAttribDivisor(4, 1);
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void UIContext::add(UIComponent* component) {
	rootComponents.reserve(rootComponents.size() + 1);
	rootComponents.emplace_back(component);
	
	for (auto& p : component->childComponents) {
		instanceData
	}
}

void UIContext::setSize(int& width, int& height) {
	int a = this->width - width, b = this->height - height;
	for (auto& p : rootComponents) {
		p->size.x += a;
		p->size.y += b;
		p->Update();
	}
}

void UIContext::DrawComponents() {
	shader->use();
	float aspect = (float)width / height;
	glm::mat4 mat = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
	//glm::mat4 mat = glm::ortho(0.0f, static_cast<float>(width), static_cast<float>(height), 0.0f);
	glUniformMatrix4fv(glGetUniformLocation(shader->getId(), "projection"), 1, GL_FALSE, glm::value_ptr(mat));
	int i = 0;
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	for (auto& p : rootComponents) {
		
		//glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(UIElements) * p->uielements.size(), p->uielements.data());
		
		
		for (auto& k : p->DrawComponent()) {
			instanceData[i] = k;
			i++;
		}
		i++;
	}
	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(Element) * instanceData.size(), instanceData.data());
	glBindVertexArray(vao);
	glDrawArraysInstanced(GL_TRIANGLES, 0, 6, instanceData.size());
	glBindVertexArray(0);
}

void UIContext::pack() {
}
